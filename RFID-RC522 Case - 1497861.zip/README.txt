RFID-RC522 Case by Gecko1 on Thingiverse: https://www.thingiverse.com/thing:1497861

Summary:
Simple case for the RFID-RC522 Reader/Writer