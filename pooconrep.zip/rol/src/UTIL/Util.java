package UTIL;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Util {

    public Util(){
    }

    public int idNext(String nombTbl, String nombCamp){
        DbBean con = new DbBean();
        int IM = 0;
        
        try{
            String sqlCount = "SELECT COUNT("+ nombCamp +") AS idMax FROM "+ nombTbl;
            ResultSet resultCount = con.execSQL(sqlCount);
            
            if(resultCount.next()){
                int countReg = resultCount.getInt(1);
                resultCount.close();
                
                if(countReg > 0){
                    System.out.append("Entrooo IM");
                    try{
                        String sqlMax = "SELECT MAX("+ nombCamp +") AS idMax FROM "+ nombTbl;
                        
                        ResultSet resultMax = con.execSQL(sqlMax);
                        if(resultMax.next()){
                            IM = resultMax.getInt(1) + 1;
                        }
                        resultMax.close();
                    }catch(SQLException e){ 
                        e.printStackTrace();
                    }
                }else{
                    IM = 1;
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        try{
            con.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        return IM;
    }
    
    public int estados(String whatEver){
        int x = 0;
        if(whatEver.equals("No Activo") ){
            x = 0;
        }
        if(whatEver.equals("Activo") ){
            x = 1;
        }
        if(whatEver.equals("Anulado") ){
            x = 2;
        }
        if(whatEver.equals("De Baja")){
            x = 3;
        }
        return x;
    }

    public String estados(int whatEver){
        String cad = "";
        switch (whatEver){
            case 0:
                cad = "No Activo";
                break;
            case 1:
                cad = "Activo";
                break;
            case 2:
                cad = "Anulado";
                break;
            case 3:
                cad = "De Baja";
                break;
        }
        return cad;
    }

    public boolean repExp(String nombTbl, String nombCamp, String cad){
        DbBean con = new DbBean();
        boolean sw = false;
        try{
            String sql = "SELECT * FROM "+ nombTbl +" where "+ nombCamp +" = '"+ cad +"'";
            ResultSet result = con.execSQL(sql); 
            
            if(result.next()){
                sw = true; 
            }else{
                sw = false;
            }
            result.close();
            
        }catch(SQLException e){
            e.printStackTrace();
        }
        try{
           con.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        return sw;
    }

    public String cadExp(String nombTbl, String campID, String nomCampBusq, String cad){
        String cade = "";
        DbBean con = new DbBean();
        try{
            String sql = "select "+ nomCampBusq +" from "+ nombTbl +" where "+ campID +" = '"+ cad +"'";
            ResultSet result = con.execSQL(sql); 
            if(result.next()){
                cade = result.getString(1);
            }else{
                cade = "";
            }
            result.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        try{
            con.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        return cade;
    }
    
    public int idExp(String nombTbl, String campID, String nomCampBusq, String cad){
        int id = 0;
        DbBean con = new DbBean();
        try{
            String sql = "select "+ campID +" from "+ nombTbl +" where "+ nomCampBusq +" = '"+ cad +"'";
            ResultSet result = con.execSQL(sql); 
            if(result.next()){
                id = result.getInt(1);
            }else{
                id = 0;
            }
            result.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        try{
            con.close(); 
        }catch(SQLException e){
            e.printStackTrace();
        }
        return id;
    }

    public String obtenerFecha(){
        String fecha = "";
        DbBean con=new DbBean();
        String sql="";

        sql = "select getdate() as fecha"; 
        
        try{
            ResultSet resultado=con.execSQL(sql); 
            resultado.next();
            fecha = resultado.getString(1);
            resultado.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        try{
            con.close(); 
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return fecha;
    }
    
    public int numRows(String sql){
        String bigSQL= "";
        int nR = 0;
        DbBean con = new DbBean();

        bigSQL = "SELECT COUNT(*) AS NumReg FROM ("+ sql +") DERIVEDTBL"; 

        try{
            ResultSet resultado = con.execSQL(bigSQL);
            if(resultado.next()){
                nR = resultado.getInt(1);
            }
            resultado.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        try{
            con.close();
        }catch(SQLException e){}
        return nR;
    }
}