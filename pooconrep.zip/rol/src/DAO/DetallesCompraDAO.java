package DAO;

import BEAN.DetallesCompra;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;
import java.sql.SQLException;

public class DetallesCompraDAO {
    public Vector<DetallesCompra> listaDetallesCompra(int idCompra) {
        DbBean con;
        con = new DbBean();
        Vector<DetallesCompra> listaDetalles;
        listaDetalles = new Vector<DetallesCompra>();
        
        String sql = "SELECT CompraID, MedicamentoID, Cantidad, PrecioUnitario FROM DetallesCompra WHERE CompraID = " + idCompra;
        
        try {
            ResultSet result = con.execSQL(sql);
            while (result.next()) {
                DetallesCompra detalle = new DetallesCompra();
                
                detalle.setCompraID(result.getInt(1));
                detalle.setMedicamentoID(result.getInt(2));
                detalle.setCantidad(result.getInt(3));
                detalle.setPrecioUnitario(result.getDouble(4));
                
                listaDetalles.addElement(detalle);
            }
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaDetalles;
    }
    
    public void insertaDetalleCompra(DetallesCompra detalle) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "INSERT INTO DetallesCompra (CompraID, MedicamentoID, Cantidad, PrecioUnitario) VALUES (";
            sql += detalle.getCompraID() + ", ";
            sql += detalle.getMedicamentoID() + ", ";
            sql += detalle.getCantidad() + ", ";
            sql += detalle.getPrecioUnitario() + ")";
            
            System.out.println("SQL INSERT DetallesCompra: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void actualizaDetalleCompra(DetallesCompra detalle) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "UPDATE DetallesCompra SET ";
            sql += "Cantidad = " + detalle.getCantidad() + ", ";
            sql += "PrecioUnitario = " + detalle.getPrecioUnitario();
            sql += " WHERE CompraID = " + detalle.getCompraID();
            sql += " AND MedicamentoID = " + detalle.getMedicamentoID();
            
            System.out.println("SQL UPDATE DetallesCompra: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void eliminaDetalleCompra(int idCompra, int idMedicamento) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "DELETE FROM DetallesCompra WHERE CompraID = " + idCompra;
            sql += " AND MedicamentoID = " + idMedicamento;
            
            System.out.println("SQL DELETE DetallesCompra: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
