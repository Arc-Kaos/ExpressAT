package DAO;

import BEAN.InstAcademica;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;
import java.sql.SQLException;

public class InstAcademicaDAO {
    
    public Vector<InstAcademica> listaInstAcademica(boolean sw, String cad) {
        DbBean con = new DbBean();
        Vector<InstAcademica> listaInst = new Vector<>();
        String sql = "select InstitucionID, NombInstitucio, TipoInst, web, Contacto, Tlf, Estado from InstAcademica";
        
        if(sw == true){
            sql = sql + " where NombInstitucio like '"+ cad +"%'";
        }

        try {
            ResultSet result = con.execSQL(sql);
            while (result.next()) {
                InstAcademica inst = new InstAcademica();
                inst.setInstitucionID(result.getInt("InstitucionID"));
                inst.setNombInstitucio(result.getString("NombInstitucio"));
                inst.setTipoInst(result.getString("TipoInst"));
                inst.setWeb(result.getString("web"));
                inst.setContacto(result.getString("Contacto"));
                inst.setTlf(result.getString("Tlf"));
                inst.setEstado(result.getInt("Estado"));
                listaInst.add(inst);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaInst;
    }

    public void insertaInstAcademica(InstAcademica inst) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "insert into InstAcademica values(";
            sql += inst.getInstitucionID() +", '";
            sql += inst.getNombInstitucio() +"', '";
            sql += inst.getTipoInst() +"', '";
            sql += inst.getWeb() +"', '";
            sql += inst.getContacto() +"', '";
            sql += inst.getTlf() +"', ";
            sql += inst.getEstado() +")";
            
            System.out.println("JJJJ "+sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void actualizaInstAcademica(InstAcademica ia) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "update InstAcademica set NombInstitucio = '"+ ia.getNombInstitucio() +"', ";
            sql += "TipoInst = '"+ ia.getTipoInst() +"', web = '"+ ia.getWeb() +"', ";
            sql += "Contacto = '"+ ia.getContacto() +"', Tlf = '"+ ia.getTlf() +"', Estado = "+ ia.getEstado() +" where ";
            sql += "InstitucionID = "+ ia.getInstitucionID();
            
            System.out.println("SQL UPDATE InstAcademica: "+sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void eliminaInstAcademica(int idInst) {
        DbBean con;
        con = new DbBean();
        String sql;
    
        try {
            sql = "delete from InstAcademica where InstitucionID = " + idInst;
        
            System.out.println("SQL DELETE InstAcademica: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}