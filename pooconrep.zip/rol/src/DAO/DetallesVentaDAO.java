package DAO;

import BEAN.DetallesVenta;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;
import java.sql.SQLException;

public class DetallesVentaDAO {
    public Vector<DetallesVenta> listaDetallesVenta(int idVenta) {
        DbBean con;
        con = new DbBean();
        Vector<DetallesVenta> listaDetalles;
        listaDetalles = new Vector<DetallesVenta>();
        
        String sql = "SELECT DetalleVentaID, VentaID, MedicamentoID, Cantidad, PrecioUnitario FROM DetallesVenta WHERE VentaID = " + idVenta;
        
        try {
            ResultSet result = con.execSQL(sql);
            while (result.next()) {
                DetallesVenta detalle = new DetallesVenta();
                
                detalle.setDetalleVentaID(result.getInt(1));
                detalle.setVentaID(result.getInt(2));
                detalle.setMedicamentoID(result.getInt(3));
                detalle.setCantidad(result.getInt(4));
                detalle.setPrecioUnitario(result.getDouble(5));
                
                listaDetalles.addElement(detalle);
            }
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaDetalles;
    }
    
    public void insertaDetalleVenta(DetallesVenta detalle) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "INSERT INTO DetallesVenta (DetalleVentaID, VentaID, MedicamentoID, Cantidad, PrecioUnitario) VALUES (";
            sql += detalle.getDetalleVentaID() + ", ";
            sql += detalle.getVentaID() + ", ";
            sql += detalle.getMedicamentoID() + ", ";
            sql += detalle.getCantidad() + ", ";
            sql += detalle.getPrecioUnitario() + ")";
            
            System.out.println("SQL INSERT DetallesVenta: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void actualizaDetalleVenta(DetallesVenta detalle) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "UPDATE DetallesVenta SET ";
            sql += "VentaID = " + detalle.getVentaID() + ", ";
            sql += "MedicamentoID = " + detalle.getMedicamentoID() + ", ";
            sql += "Cantidad = " + detalle.getCantidad() + ", ";
            sql += "PrecioUnitario = " + detalle.getPrecioUnitario();
            sql += " WHERE DetalleVentaID = " + detalle.getDetalleVentaID();
            
            System.out.println("SQL UPDATE DetallesVenta: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void eliminaDetalleVenta(int idDetalleVenta) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            // por clave primaria simple (DetalleVentaID)
            sql = "DELETE FROM DetallesVenta WHERE DetalleVentaID = " + idDetalleVenta;
            
            System.out.println("SQL DELETE DetallesVenta: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
