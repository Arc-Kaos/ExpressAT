package DAO;

import BEAN.Ubigeo;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;
import java.sql.SQLException;

public class UbigeoDAO {
    
    public Vector<Ubigeo> listaUbigeos(boolean sw, String cad) {
        DbBean con;
        con = new DbBean();
        Vector<Ubigeo> listaUbi;
        listaUbi = new Vector<Ubigeo>();
        
        String sql = "select * from Ubigeo";
        
        if (sw == true) {
            sql = sql + " where Region like '"+ cad +"%' OR Departamento like '"+ cad +"%' OR Provincia like '"+ cad +"%' OR Distrito like '"+ cad +"%'";
        }
        
        try {
            ResultSet result = con.execSQL(sql);
            while (result.next()) {
                Ubigeo ubi = new Ubigeo();
                ubi.setUbigeoId(result.getInt(1)); 
                ubi.setRegion(result.getString(2));
                ubi.setDepartamento(result.getString(3)); 
                ubi.setProvincia(result.getString(4)); 
                ubi.setDistrito(result.getString(5)); 
                
                listaUbi.addElement(ubi);
            }
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaUbi;
    }
    
    public void insertaUbigeo(Ubigeo ubi){
        DbBean con;
        con = new DbBean();
        String sql;
        
        try{
            sql = "insert into Ubigeo values("+ ubi.getUbigeoId() +", '"+ ubi.getRegion() +"', ";
            sql += " '"+ ubi.getDepartamento() +"', '"+ ubi.getProvincia() +"', '"+ ubi.getDistrito() +"')";
            
            System.out.println("JJJJ "+sql);
            con.updateSQL(sql);
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        try{
            con.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public void actualizaUbigeo(Ubigeo ubi){
        DbBean con;
        con = new DbBean();
        String sql;
        
        try{
            sql = "update Ubigeo set Region = '"+ ubi.getRegion() +"', ";
            sql += "Departamento = '"+ ubi.getDepartamento() +"', Provincia = '"+ ubi.getProvincia() +"', ";
            sql += "Distrito = '"+ ubi.getDistrito() +"' where UbigeoID = "+ ubi.getUbigeoId();
            
            System.out.println("TICO TIco: \"+sql");
            con.updateSQL(sql);
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        try{
            con.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public void eliminarUbigeo(int UbigeoId) {
        DbBean con;
        con = new DbBean();
        String sql;
        
        try {
            sql = "delete from Ubigeo where UbigeoId = " + UbigeoId;
            
            System.out.println("SQL DELETE Ubigeo: " + sql);
            con.updateSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}