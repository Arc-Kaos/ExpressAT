package BEAN;


public class InstAcademica {
private int institucionID;
private String nombInstitucio;
private String tipoInst;
private String web;
private String contacto;
private String tlf;
private int estado;


public int getInstitucionID() {
return institucionID;
}


public void setInstitucionID(int institucionID) {
this.institucionID = institucionID;
}


public String getNombInstitucio() {
return nombInstitucio;
}


public void setNombInstitucio(String nombInstitucio) {
this.nombInstitucio = nombInstitucio;
}


public String getTipoInst() {
return tipoInst;
}


public void setTipoInst(String tipoInst) {
this.tipoInst = tipoInst;
}


public String getWeb() {
return web;
}


public void setWeb(String web) {
this.web = web;
}


public String getContacto() {
return contacto;
}


public void setContacto(String contacto) {
this.contacto = contacto;
}


public String getTlf() {
return tlf;
}


public void setTlf(String tlf) {
this.tlf = tlf;
}


public int getEstado() {
return estado;
}


public void setEstado(int estado) {
this.estado = estado;
}
}