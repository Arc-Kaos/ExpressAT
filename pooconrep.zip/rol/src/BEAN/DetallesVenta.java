package BEAN;
public class DetallesVenta {
    private int DetalleVentaID;
    private int VentaID;
    private int MedicamentoID;
    private int Cantidad;
    private double PrecioUnitario;

    public DetallesVenta() {
    }

    public DetallesVenta(int DetalleVentaID, int VentaID, int MedicamentoID, int Cantidad, double PrecioUnitario) {
        this.DetalleVentaID = DetalleVentaID;
        this.VentaID = VentaID;
        this.MedicamentoID = MedicamentoID;
        this.Cantidad = Cantidad;
        this.PrecioUnitario = PrecioUnitario;
    }

    public int getDetalleVentaID() {
        return DetalleVentaID;
    }

    public void setDetalleVentaID(int DetalleVentaID) {
        this.DetalleVentaID = DetalleVentaID;
    }

    public int getVentaID() {
        return VentaID;
    }

    public void setVentaID(int VentaID) {
        this.VentaID = VentaID;
    }

    public int getMedicamentoID() {
        return MedicamentoID;
    }

    public void setMedicamentoID(int MedicamentoID) {
        this.MedicamentoID = MedicamentoID;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public double getPrecioUnitario() {
        return PrecioUnitario;
    }

    public void setPrecioUnitario(double PrecioUnitario) {
        this.PrecioUnitario = PrecioUnitario;
    }
}
