package BEAN;

public class DetallesCompra {
    private int CompraID;
    private int MedicamentoID;
    private int Cantidad;
    private double PrecioUnitario;

    public DetallesCompra() {
    }

    public DetallesCompra(int CompraID, int MedicamentoID, int Cantidad, double PrecioUnitario) {
        this.CompraID = CompraID;
        this.MedicamentoID = MedicamentoID;
        this.Cantidad = Cantidad;
        this.PrecioUnitario = PrecioUnitario;
    }

    public int getCompraID() {
        return CompraID;
    }

    public void setCompraID(int CompraID) {
        this.CompraID = CompraID;
    }

    public int getMedicamentoID() {
        return MedicamentoID;
    }

    public void setMedicamentoID(int MedicamentoID) {
        this.MedicamentoID = MedicamentoID;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public double getPrecioUnitario() {
        return PrecioUnitario;
    }

    public void setPrecioUnitario(double PrecioUnitario) {
        this.PrecioUnitario = PrecioUnitario;
    }
}
