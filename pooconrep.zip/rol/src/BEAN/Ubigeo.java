package BEAN;

public class Ubigeo {

private int UbigeoId;
private String Region;
private String Departamento;
private String Provincia;
private String Distrito;

    public Ubigeo() {
    }

    public Ubigeo(int UbigeoId, String Region, String Departamento, String Provincia, String Distrito) {
        this.UbigeoId = UbigeoId;
        this.Region = Region;
        this.Departamento = Departamento;
        this.Provincia = Provincia;
        this.Distrito = Distrito;
    }

    public int getUbigeoId() {
        return UbigeoId;
    }

    public void setUbigeoId(int UbigeoId) {
        this.UbigeoId = UbigeoId;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getDepartamento() {
        return Departamento;
    }

    public void setDepartamento(String Departamento) {
        this.Departamento = Departamento;
    }

    public String getProvincia() {
        return Provincia;
    }

    public void setProvincia(String Provincia) {
        this.Provincia = Provincia;
    }

    public String getDistrito() {
        return Distrito;
    }

    public void setDistrito(String Distrito) {
        this.Distrito = Distrito;
    }

}
