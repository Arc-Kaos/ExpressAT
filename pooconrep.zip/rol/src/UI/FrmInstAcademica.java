package UI;

import BEAN.InstAcademica;
import DAO.InstAcademicaDAO;
import UTIL.Util;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmInstAcademica extends javax.swing.JInternalFrame {

    InstAcademicaDAO instDao; 
    DefaultTableModel dtm;
    int idInst;
    
    public FrmInstAcademica() {
        instDao = new InstAcademicaDAO();
        initComponents();
        dtm = (DefaultTableModel)this.tblInstAcademica.getModel(); 

        llenaCmbTipo();
        llenaCmbEstado(); 
        llenaTblInstAcademica(false, "");
        limpia();
    }
    
    private void llenaCmbTipo(){
        this.cmbTipoInst.addItem("");
        this.cmbTipoInst.addItem("Pública"); 
        this.cmbTipoInst.addItem("Privada"); 
    }
    
    private void llenaCmbEstado(){
        this.cmbEstado.addItem("");
        this.cmbEstado.addItem("Activo");
        this.cmbEstado.addItem("No Activo");
    }
    
    private void llenaTblInstAcademica(boolean sw, String cad){
        Vector<InstAcademica> listaI;
        listaI = instDao.listaInstAcademica(sw, cad); 
        dtm.setRowCount(0);
        
        for(int i=0; i<listaI.size(); i++){
            Vector vec = new Vector();
            vec.addElement(listaI.get(i).getInstitucionID());
            vec.addElement(listaI.get(i).getNombInstitucio());
            vec.addElement(listaI.get(i).getTipoInst());
            vec.addElement(listaI.get(i).getWeb());
            vec.addElement(listaI.get(i).getContacto());
            vec.addElement(listaI.get(i).getTlf());
            vec.addElement(listaI.get(i).getEstado());
            dtm.addRow(vec);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblInstAcademica = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        txtIdInstitucion = new javax.swing.JTextField();
        txtNombInstitucio = new javax.swing.JTextField();
        txtWeb = new javax.swing.JTextField();
        txtContacto = new javax.swing.JTextField();
        txtTlf = new javax.swing.JTextField();
        cmbTipoInst = new javax.swing.JComboBox();
        cmbEstado = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        btnEliminar = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 153));
        jLabel1.setText("MANTENIMIENTO INSTITUCIÓN ACADÉMICA");

        jLabel2.setText("ID Institución");

        jLabel3.setText("Nombre Institución");

        jLabel4.setText("Tipo Institución");

        jLabel5.setText("Web");

        jLabel6.setText("Contacto");

        jLabel7.setText("Teléfono");

        jLabel8.setText("Estado");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tblInstAcademica.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Institucion", "Nombre Institucion", "Tipo Institucion", "Web", "Contacto", "Telefono", "Estado"
            }
        ));
        tblInstAcademica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblInstAcademicaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblInstAcademica);

        jLabel9.setText("Buscar:");

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtBuscar)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
                .addContainerGap())
        );

        txtIdInstitucion.setEnabled(false);

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnGrabar.setText("Grabar");
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(247, 247, 247)
                .addComponent(btnGrabar)
                .addGap(37, 37, 37)
                .addComponent(btnEliminar)
                .addGap(31, 31, 31)
                .addComponent(btnLimpiar)
                .addGap(55, 55, 55)
                .addComponent(btnSalir))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEliminar)
                        .addComponent(btnGrabar)
                        .addComponent(btnLimpiar))
                    .addComponent(btnSalir)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(52, 52, 52)
                                .addComponent(txtIdInstitucion, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addGap(38, 38, 38))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(18, 18, 18)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel8))
                                        .addGap(75, 75, 75)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNombInstitucio)
                                    .addComponent(txtWeb)
                                    .addComponent(txtContacto)
                                    .addComponent(txtTlf)
                                    .addComponent(cmbTipoInst, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cmbEstado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(274, 274, 274))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtIdInstitucion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtNombInstitucio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cmbTipoInst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtWeb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtContacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtTlf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(17, 17, 17)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        if(this.txtBuscar.getText().isEmpty()){
            this.llenaTblInstAcademica(false, "");
        }else{
            this.llenaTblInstAcademica(true, this.txtBuscar.getText());
        }
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void tblInstAcademicaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblInstAcademicaMouseClicked
        int idx;
        idx = this.tblInstAcademica.getSelectedRow();
        
        idInst = Integer.parseInt(dtm.getValueAt(idx, 0).toString());
        this.txtIdInstitucion.setText(dtm.getValueAt(idx, 0).toString());
        this.txtNombInstitucio.setText(dtm.getValueAt(idx, 1).toString());
        
        this.cmbTipoInst.setSelectedItem(dtm.getValueAt(idx, 2).toString());
        
        this.txtWeb.setText(dtm.getValueAt(idx, 3).toString());
        this.txtContacto.setText(dtm.getValueAt(idx, 4).toString());
        this.txtTlf.setText(dtm.getValueAt(idx, 5).toString());
        
        this.cmbEstado.setSelectedItem(dtm.getValueAt(idx, 6).toString().equals("1") ? "Activo" : "No Activo");
        
        this.btnGrabar.setText("Actualizar");
    }//GEN-LAST:event_tblInstAcademicaMouseClicked

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpia();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if (this.idInst == 0) {
        JOptionPane.showMessageDialog(this, "Debe seleccionar una institución de la tabla para eliminar.", "Error", JOptionPane.WARNING_MESSAGE);
        return;
        }
    
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro de que desea eliminar la institución con ID: " + this.idInst + "?",
            "Confirmar Eliminación",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                instDao.eliminaInstAcademica(this.idInst);
            
                limpia();
                llenaTblInstAcademica(false, "");
                JOptionPane.showMessageDialog(this, "Institución eliminada correctamente.");
            
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar la institución: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
        if (!valida()) {
        return;
        }
        Util u = new Util(); 
        InstAcademica inst = new InstAcademica();

        inst.setNombInstitucio(this.txtNombInstitucio.getText());
        inst.setTipoInst(this.cmbTipoInst.getSelectedItem().toString());
        inst.setWeb(this.txtWeb.getText());
        inst.setContacto(this.txtContacto.getText());
        inst.setTlf(this.txtTlf.getText());
        
        inst.setEstado(this.cmbEstado.getSelectedItem().toString().equals("Activo") ? 1 : 0);
        
        if(this.btnGrabar.getText().equals("Grabar")){
            this.idInst = u.idNext("InstAcademica", "InstitucionID");
            inst.setInstitucionID(idInst);
            instDao.insertaInstAcademica(inst);
        }else{
            inst.setInstitucionID(idInst);
            instDao.actualizaInstAcademica(inst);
        }
        
        limpia();
        JOptionPane.showMessageDialog(this, "Institución Académica procesada correctamente");
        this.llenaTblInstAcademica(false, "");
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void limpia(){
        this.txtIdInstitucion.setText("");
        this.txtNombInstitucio.setText("");
        this.txtWeb.setText("");
        this.txtContacto.setText("");
        this.txtTlf.setText("");
        this.cmbTipoInst.setSelectedItem("");
        this.cmbEstado.setSelectedItem("");
        this.btnGrabar.setText("Grabar");  
    }
    
    private boolean valida() {
    boolean sw = false;
    String cad = "";

    if (this.txtNombInstitucio.getText().trim().isEmpty()) {
        cad = "Debe registrar el nombre de la institución";
    }
    if (this.cmbTipoInst.getSelectedItem() == null ||
        this.cmbTipoInst.getSelectedItem().toString().trim().isEmpty()) {
        cad += "\nDebe seleccionar el tipo de institución";
    }
    if (this.txtWeb.getText().trim().isEmpty()) {
        cad += "\nDebe registrar la página web";
    }
    if (this.txtContacto.getText().trim().isEmpty()) {
        cad += "\nDebe registrar el contacto";
    }
    if (this.txtTlf.getText().trim().isEmpty()) {
        cad += "\nDebe registrar el teléfono";
    }

    if (this.cmbEstado.getSelectedItem() == null ||
        this.cmbEstado.getSelectedItem().toString().trim().isEmpty()) {
        cad += "\nDebe seleccionar el estado";
    }
    if (cad.isEmpty()) {
        sw = true;
    } else {
        JOptionPane.showMessageDialog(this, cad, "Campos incompletos", JOptionPane.WARNING_MESSAGE);
    }

    return sw;
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox cmbEstado;
    private javax.swing.JComboBox cmbTipoInst;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblInstAcademica;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtContacto;
    private javax.swing.JTextField txtIdInstitucion;
    private javax.swing.JTextField txtNombInstitucio;
    private javax.swing.JTextField txtTlf;
    private javax.swing.JTextField txtWeb;
    // End of variables declaration//GEN-END:variables
}
