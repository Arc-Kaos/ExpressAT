package UI;

import UTIL.DbBean;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.SQLException;
import javax.swing.JFrame;
import net.sf.jasperreports.engine.JRException;

public class MDI extends javax.swing.JFrame {

    frmRepInstTipo repInst;
    
    private int wd;
    private int hd;
    
    public MDI() {
        initComponents();
        
        Toolkit toolkit =  Toolkit.getDefaultToolkit ();
        Dimension dim = toolkit.getScreenSize();
        wd = dim.width;
        hd = dim.height;
        
        System.out.println("WD: "+wd);
        System.out.println("HD: "+hd);
        this.setSize(wd, hd);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
    
    public int dimH() { return hd; }  // getter de altura
    public int dimW() { return wd; }  // getter de ancho


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        escritorio = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        smnuInstAcad = new javax.swing.JMenuItem();
        smnuUbigeo = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        smnuRepUbigeo = new javax.swing.JMenuItem();
        smnuInstSimp = new javax.swing.JMenuItem();
        smnuInstxtipo = new javax.swing.JMenuItem();
        smnuUbigxDep = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout escritorioLayout = new javax.swing.GroupLayout(escritorio);
        escritorio.setLayout(escritorioLayout);
        escritorioLayout.setHorizontalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 676, Short.MAX_VALUE)
        );
        escritorioLayout.setVerticalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 444, Short.MAX_VALUE)
        );

        jMenu1.setText("Mantenimiento");

        smnuInstAcad.setText("Institución Académica");
        smnuInstAcad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuInstAcadActionPerformed(evt);
            }
        });
        jMenu1.add(smnuInstAcad);

        smnuUbigeo.setText("Ubigeo");
        smnuUbigeo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuUbigeoActionPerformed(evt);
            }
        });
        jMenu1.add(smnuUbigeo);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Transacciones");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Reportes");

        smnuRepUbigeo.setText("Ubigeo Simple");
        smnuRepUbigeo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuRepUbigeoActionPerformed(evt);
            }
        });
        jMenu3.add(smnuRepUbigeo);

        smnuInstSimp.setText("Institución Simple");
        smnuInstSimp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuInstSimpActionPerformed(evt);
            }
        });
        jMenu3.add(smnuInstSimp);

        smnuInstxtipo.setText("Institución por tipo");
        smnuInstxtipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuInstxtipoActionPerformed(evt);
            }
        });
        jMenu3.add(smnuInstxtipo);

        smnuUbigxDep.setText("Ubigeo por Departamento");
        smnuUbigxDep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuUbigxDepActionPerformed(evt);
            }
        });
        jMenu3.add(smnuUbigxDep);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(escritorio)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(escritorio)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void smnuInstAcadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuInstAcadActionPerformed
        FrmInstAcademica frmInstAcad;
        frmInstAcad= new FrmInstAcademica();
        escritorio.add(frmInstAcad);
        frmInstAcad.setVisible(true);
    }//GEN-LAST:event_smnuInstAcadActionPerformed

    private void smnuUbigeoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuUbigeoActionPerformed
        FrmUbigeo frmUbigeo;
        frmUbigeo= new FrmUbigeo();
        escritorio.add(frmUbigeo);
        frmUbigeo.setVisible(true);
    }//GEN-LAST:event_smnuUbigeoActionPerformed

    private void smnuRepUbigeoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuRepUbigeoActionPerformed
        try {
            String r = "src/REPORTES/repUbiSimp.jasper";
            DbBean db = new DbBean();
            db.connectRep(r, null, false);
        }catch(SQLException ex){
            ex.printStackTrace();
        }catch(JRException ex){
            ex.printStackTrace();
        }
    }//GEN-LAST:event_smnuRepUbigeoActionPerformed

    private void smnuInstSimpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuInstSimpActionPerformed
        try {
            String r = "src/REPORTES/repInstAcadSimp.jasper";
            DbBean db = new DbBean();
            db.connectRep(r, null, false);
        }catch(SQLException ex){
            ex.printStackTrace();
        }catch(JRException ex){
            ex.printStackTrace();
        }
    }//GEN-LAST:event_smnuInstSimpActionPerformed

    private void smnuInstxtipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuInstxtipoActionPerformed
        int escW = escritorio.getWidth();
        int escH = escritorio.getHeight();

        frmRepInstTipo frm = new frmRepInstTipo(escH, escW);
        escritorio.add(frm);
        frm.setVisible(true);
    }//GEN-LAST:event_smnuInstxtipoActionPerformed

    private void smnuUbigxDepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuUbigxDepActionPerformed
        int escW = escritorio.getWidth();
        int escH = escritorio.getHeight();

        frmRepUbigDep frm = new frmRepUbigDep(escH, escW);
        escritorio.add(frm);
        frm.setVisible(true);
    }//GEN-LAST:event_smnuUbigxDepActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MDI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane escritorio;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem smnuInstAcad;
    private javax.swing.JMenuItem smnuInstSimp;
    private javax.swing.JMenuItem smnuInstxtipo;
    private javax.swing.JMenuItem smnuRepUbigeo;
    private javax.swing.JMenuItem smnuUbigeo;
    private javax.swing.JMenuItem smnuUbigxDep;
    // End of variables declaration//GEN-END:variables
}
