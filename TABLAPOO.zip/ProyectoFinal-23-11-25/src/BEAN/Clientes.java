package BEAN;
public class Clientes {
   private int ClienteID;
   private String Nombre;
   private String Apellido;
   private String Direccion;
   private String Telefono;
   private String DNI;
   private int Genero;
   private int EstCivil;
   private int Estado;

    public Clientes( ) {
    }

    public Clientes(int ClienteID, String Nombre, String Apellido, String Direccion, String Telefono, String DNI, int Genero, int EstCivil, int Estado) {
        this.ClienteID = ClienteID;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.DNI = DNI;
        this.Genero = Genero;
        this.EstCivil = EstCivil;
        this.Estado = Estado;
    }

    public int getClienteID() {
        return ClienteID;
    }

    public void setClienteID(int ClienteID) {
        this.ClienteID = ClienteID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public int getGenero() {
        return Genero;
    }

    public void setGenero(int Genero) {
        this.Genero = Genero;
    }

    public int getEstCivil() {
        return EstCivil;
    }

    public void setEstCivil(int EstCivil) {
        this.EstCivil = EstCivil;
    }

    public int getEstado() {
        return Estado;
    }

    public void setEstado(int Estado) {
        this.Estado = Estado;
    }
       
   
           
}
