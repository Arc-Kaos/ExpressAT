package BEAN;

public class Categoria {
    private int CategoriaID;
    private String DescCategoria;
    private String Obs;

    public int getCategoriaID() {
        return CategoriaID;
    }

    public void setCategoriaID(int CategoriaID) {
        this.CategoriaID = CategoriaID;
    }

    public String getDescCategoria() {
        return DescCategoria;
    }

    public void setDescCategoria(String DescCategoria) {
        this.DescCategoria = DescCategoria;
    }

    public String getObs() {
        return Obs;
    }

    public void setObs(String Obs) {
        this.Obs = Obs;
    }
}

