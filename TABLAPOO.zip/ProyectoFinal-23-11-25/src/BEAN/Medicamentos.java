package BEAN;

public class Medicamentos {
    private int MedicamentoID;
    private int CategoriaID;
    private int ProveedorID;
    private String Nombre;
    private String Descripcion;
    private double Precio;
    private int Stock;
    private String FechaExpiracion;

    public Medicamentos() {
    }

    public Medicamentos(int MedicamentoID, int CategoriaID, int ProveedorID, String Nombre, String Descripcion, double Precio, int Stock, String FechaExpiracion) {
        this.MedicamentoID = MedicamentoID;
        this.CategoriaID = CategoriaID;
        this.ProveedorID = ProveedorID;
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.Precio = Precio;
        this.Stock = Stock;
        this.FechaExpiracion = FechaExpiracion;
    }

    public int getMedicamentoID() {
        return MedicamentoID;
    }

    public void setMedicamentoID(int MedicamentoID) {
        this.MedicamentoID = MedicamentoID;
    }

    public int getCategoriaID() {
        return CategoriaID;
    }

    public void setCategoriaID(int CategoriaID) {
        this.CategoriaID = CategoriaID;
    }

    public int getProveedorID() {
        return ProveedorID;
    }

    public void setProveedorID(int ProveedorID) {
        this.ProveedorID = ProveedorID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

    public String getFechaExpiracion() {
        return FechaExpiracion;
    }

    public void setFechaExpiracion(String FechaExpiracion) {
        this.FechaExpiracion = FechaExpiracion;
    }
}
