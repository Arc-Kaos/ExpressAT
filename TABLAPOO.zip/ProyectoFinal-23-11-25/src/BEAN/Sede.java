
package BEAN;

public class Sede {
    private int SedeID;
    private int UbigeoId;
    private String NombSede;
    private String Direccion;
    private String Tlf;

public Sede (){
    
}
    public Sede(int SedeID, int UbigeoId, String NombSede, String Direccion, String Tlf) {
        this.SedeID = SedeID;
        this.UbigeoId = UbigeoId;
        this.NombSede = NombSede;
        this.Direccion = Direccion;
        this.Tlf = Tlf;
    }

    public int getSedeID() {
        return SedeID;
    }

    public void setSedeID(int SedeID) {
        this.SedeID = SedeID;
    }

    public int getUbigeoId() {
        return UbigeoId;
    }

    public void setUbigeoId(int UbigeoId) {
        this.UbigeoId = UbigeoId;
    }

    public String getNombSede() {
        return NombSede;
    }

    public void setNombSede(String NombSede) {
        this.NombSede = NombSede;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTlf() {
        return Tlf;
    }

    public void setTlf(String Tlf) {
        this.Tlf = Tlf;
    }


}