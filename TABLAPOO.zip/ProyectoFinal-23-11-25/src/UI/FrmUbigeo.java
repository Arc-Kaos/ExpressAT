package UI;

import BEAN.Ubigeo;
import DAO.UbigeoDAO;
import UTIL.Util;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class FrmUbigeo extends javax.swing.JInternalFrame {
    UbigeoDAO ubiDao;
    DefaultTableModel dtm;
    int idUbi;



    public FrmUbigeo() {
        ubiDao = new UbigeoDAO();
        initComponents();
        //setLocationRelativeTo(null);
        dtm = (DefaultTableModel) this.tblUbigeo.getModel();
        llenaTblUbigeo("");
        this.txtUbigeoId.setEnabled(false);   // Id solo lectura
    }


    private void llenaTblUbigeo(String cad) {
        Vector<Ubigeo> listaUbi;
        listaUbi = ubiDao.listaUbigeos(cad);
        dtm.setRowCount(0);
        for (int i = 0; i < listaUbi.size(); i++) {
            Vector vec = new Vector();
            vec.addElement(listaUbi.get(i).getUbigeoId());
            vec.addElement(listaUbi.get(i).getRegion());
            vec.addElement(listaUbi.get(i).getDepartamento());
            vec.addElement(listaUbi.get(i).getProvincia());
            vec.addElement(listaUbi.get(i).getDistrito());
            dtm.addRow(vec);
        }
    }
    private boolean valida() {
        boolean sw = false;
        String cad = "";
        if (this.txtRegion.getText().isEmpty()) {
            cad = "Debe registrar la región";
        }
        if (this.txtDepartamento.getText().isEmpty()) {
            cad += "\nDebe registrar el departamento";
        }
        if (this.txtProvincia.getText().isEmpty()) {
            cad += "\nDebe registrar la provincia";
        }
        if (this.txtDistrito.getText().isEmpty()) {
            cad += "\nDebe registrar el distrito";
        }
        if (cad.isEmpty()) {
            sw = true;
        } else {
            JOptionPane.showMessageDialog(this, cad);
        }
        return sw;
}
    private void limpia() {
    this.txtUbigeoId.setText("");
    this.txtRegion.setText("");
    this.txtDepartamento.setText("");
    this.txtProvincia.setText("");
    this.txtDistrito.setText("");
    this.txtBuscar.setText("");
    this.btnGrabar.setText("Grabar");
    this.tblUbigeo.clearSelection();
    idUbi = 0;
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtUbigeoId = new javax.swing.JTextField();
        txtRegion = new javax.swing.JTextField();
        txtDepartamento = new javax.swing.JTextField();
        txtProvincia = new javax.swing.JTextField();
        txtDistrito = new javax.swing.JTextField();
        btnGrabar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblUbigeo = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 153, 255));
        jLabel1.setText("MANTENIMIENTO UBIGEO");

        jLabel2.setText("Id Ubigeo");

        jLabel3.setText("Region");

        jLabel4.setText("Departamento");

        jLabel5.setText("Provincia");

        jLabel6.setText("Distrito");

        btnGrabar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnGrabar.setText("Grabar");
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnSalir.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel7.setText("Buscar");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(40, 30, 32, 14);

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        jPanel1.add(txtBuscar);
        txtBuscar.setBounds(110, 30, 350, 20);

        tblUbigeo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Ubigeo", "Region", "Departamento", "Provincia", "Distrito"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblUbigeo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblUbigeoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblUbigeo);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(30, 70, 430, 180);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addComponent(btnGrabar)
                .addGap(253, 253, 253)
                .addComponent(btnLimpiar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(129, 129, 129))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addGap(57, 57, 57))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(72, 72, 72)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6))
                                .addGap(30, 30, 30)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtUbigeoId)
                            .addComponent(txtRegion)
                            .addComponent(txtDepartamento)
                            .addComponent(txtProvincia)
                            .addComponent(txtDistrito, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE))
                        .addGap(97, 97, 97)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(316, 316, 316)
                        .addComponent(jLabel1)))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtUbigeoId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtRegion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(txtDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtProvincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtDistrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGrabar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnSalir))
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
if (valida() == true) {
    Util util = new Util();
    Ubigeo ubi = new Ubigeo();
    String msj;

    ubi.setRegion(this.txtRegion.getText());
    ubi.setDepartamento(this.txtDepartamento.getText());
    ubi.setProvincia(this.txtProvincia.getText());
    ubi.setDistrito(this.txtDistrito.getText());

    if (this.btnGrabar.getText().equals("Grabar")) {
        idUbi = util.idNext("Ubigeo", "UbigeoId");
        ubi.setUbigeoId(idUbi);
        this.ubiDao.insertaUbigeo(ubi);
        msj = "Ubigeo registrado exitosamente";
    } else {
        ubi.setUbigeoId(idUbi);
        this.ubiDao.actualizaUbigeo(ubi);
        msj = "Ubigeo actualizado exitosamente";
    }

    JOptionPane.showMessageDialog(this, msj);
    this.llenaTblUbigeo("");
    limpia();
}
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
    limpia();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        if (this.txtBuscar.getText().isEmpty()) {
            this.llenaTblUbigeo("");
        } else {
            this.llenaTblUbigeo(this.txtBuscar.getText());
        }

    }//GEN-LAST:event_txtBuscarKeyReleased

    private void tblUbigeoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblUbigeoMouseClicked
    int idx;
    idx = this.tblUbigeo.getSelectedRow();
    this.idUbi = Integer.parseInt(dtm.getValueAt(idx, 0).toString());
    this.txtUbigeoId.setText(dtm.getValueAt(idx, 0).toString());
    this.txtRegion.setText(dtm.getValueAt(idx, 1).toString());
    this.txtDepartamento.setText(dtm.getValueAt(idx, 2).toString());
    this.txtProvincia.setText(dtm.getValueAt(idx, 3).toString());
    this.txtDistrito.setText(dtm.getValueAt(idx, 4).toString());
    this.btnGrabar.setText("Actualizar");
    
    }//GEN-LAST:event_tblUbigeoMouseClicked

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblUbigeo;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDepartamento;
    private javax.swing.JTextField txtDistrito;
    private javax.swing.JTextField txtProvincia;
    private javax.swing.JTextField txtRegion;
    private javax.swing.JTextField txtUbigeoId;
    // End of variables declaration//GEN-END:variables
}
