package UI;

import UTIL.DbBean;
import java.awt.*;
import java.awt.Dimension;
import net.sf.jasperreports.engine.JRException;

public class MDI extends javax.swing.JFrame {
    private int wd;
    private int hd;
    
    public MDI() {
        initComponents();
       
        Toolkit toolkit =  Toolkit.getDefaultToolkit ();
        Dimension dim = toolkit.getScreenSize();
        wd = dim.width;
        hd = dim.height;
        
        System.out.println("WD: "+wd);
        System.out.println("HD: "+hd);
        this.setSize(1500, 1000);
        setLocationRelativeTo(null); // Centrar ventana
        }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        escritorio = new javax.swing.JDesktopPane();
        jMenuBar2 = new javax.swing.JMenuBar();
        mnuMantenimiento = new javax.swing.JMenu();
        smnuClientes = new javax.swing.JMenuItem();
        smnuCategoria = new javax.swing.JMenuItem();
        smnuProveedores = new javax.swing.JMenuItem();
        smnuMedicamentos = new javax.swing.JMenuItem();
        smnuEmpleados = new javax.swing.JMenuItem();
        smnuSede = new javax.swing.JMenuItem();
        smnuUbigeo = new javax.swing.JMenuItem();
        mnuReportes = new javax.swing.JMenu();
        smnuReportMedicamentosSimp = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout escritorioLayout = new javax.swing.GroupLayout(escritorio);
        escritorio.setLayout(escritorioLayout);
        escritorioLayout.setHorizontalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 852, Short.MAX_VALUE)
        );
        escritorioLayout.setVerticalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 494, Short.MAX_VALUE)
        );

        getContentPane().add(escritorio, java.awt.BorderLayout.CENTER);

        mnuMantenimiento.setText("Mantenimiento");

        smnuClientes.setText("Clientes");
        smnuClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuClientesActionPerformed(evt);
            }
        });
        mnuMantenimiento.add(smnuClientes);

        smnuCategoria.setText("Categoria");
        smnuCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuCategoriaActionPerformed(evt);
            }
        });
        mnuMantenimiento.add(smnuCategoria);

        smnuProveedores.setText("Proveedores");
        smnuProveedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuProveedoresActionPerformed(evt);
            }
        });
        mnuMantenimiento.add(smnuProveedores);

        smnuMedicamentos.setText("Medicamentos");
        smnuMedicamentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuMedicamentosActionPerformed(evt);
            }
        });
        mnuMantenimiento.add(smnuMedicamentos);

        smnuEmpleados.setText("Empleados");
        smnuEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuEmpleadosActionPerformed(evt);
            }
        });
        mnuMantenimiento.add(smnuEmpleados);

        smnuSede.setText("Sede");
        smnuSede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuSedeActionPerformed(evt);
            }
        });
        mnuMantenimiento.add(smnuSede);

        smnuUbigeo.setText("Ubigeo");
        smnuUbigeo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuUbigeoActionPerformed(evt);
            }
        });
        mnuMantenimiento.add(smnuUbigeo);

        jMenuBar2.add(mnuMantenimiento);

        mnuReportes.setText("Reportes");

        smnuReportMedicamentosSimp.setText("ReproteMedicamentos");
        smnuReportMedicamentosSimp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smnuReportMedicamentosSimpActionPerformed(evt);
            }
        });
        mnuReportes.add(smnuReportMedicamentosSimp);

        jMenuItem1.setText("RepSede");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        mnuReportes.add(jMenuItem1);

        jMenuBar2.add(mnuReportes);

        setJMenuBar(jMenuBar2);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void smnuClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuClientesActionPerformed
        FrmClientes frmClien;
        frmClien = new FrmClientes();
        escritorio.add(frmClien);
        frmClien.show();
        
    }//GEN-LAST:event_smnuClientesActionPerformed

    private void smnuCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuCategoriaActionPerformed
        FrmCategoria frmCat;
        frmCat = new FrmCategoria();
        escritorio.add(frmCat);
        frmCat.show();
    }//GEN-LAST:event_smnuCategoriaActionPerformed

    private void smnuMedicamentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuMedicamentosActionPerformed
        FrmMedicamentos frmMed;
        frmMed = new FrmMedicamentos();
        escritorio.add(frmMed);
        frmMed.show();
    }//GEN-LAST:event_smnuMedicamentosActionPerformed

    private void smnuProveedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuProveedoresActionPerformed
        FrmProveedores frmProv;
        frmProv = new FrmProveedores();
        escritorio.add(frmProv);
        frmProv.show();
    }//GEN-LAST:event_smnuProveedoresActionPerformed

    private void smnuEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuEmpleadosActionPerformed
           
    }//GEN-LAST:event_smnuEmpleadosActionPerformed

    private void smnuSedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuSedeActionPerformed
        FrmSede frmSed;
        frmSed = new FrmSede();
        escritorio.add(frmSed);
         frmSed.setVisible(true);  
        frmSed.show();
        
    }//GEN-LAST:event_smnuSedeActionPerformed

    private void smnuUbigeoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuUbigeoActionPerformed
        FrmUbigeo frmUbi;
        frmUbi = new FrmUbigeo();
        escritorio.add(frmUbi);
        frmUbi.show();
        
    }//GEN-LAST:event_smnuUbigeoActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        try{
            String r = "src/Reportes/repSede.jasper";
            DbBean con  = new DbBean();
            con.connectRep(r, null, false);
        }catch(java.sql.SQLException ex){
            ex.printStackTrace();
        }catch(JRException e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void smnuReportMedicamentosSimpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smnuReportMedicamentosSimpActionPerformed
        try{
            String r = "src/Reportes/repMedicamentos.jasper";
            DbBean con  = new DbBean();
            con.connectRep(r, null, false);
        }catch(java.sql.SQLException ex){
            ex.printStackTrace();
        }catch(JRException e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_smnuReportMedicamentosSimpActionPerformed
    int dimH(){
        return wd;
    }
    int dimW(){
        return hd;
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MDI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MDI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane escritorio;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenu mnuMantenimiento;
    private javax.swing.JMenu mnuReportes;
    private javax.swing.JMenuItem smnuCategoria;
    private javax.swing.JMenuItem smnuClientes;
    private javax.swing.JMenuItem smnuEmpleados;
    private javax.swing.JMenuItem smnuMedicamentos;
    private javax.swing.JMenuItem smnuProveedores;
    private javax.swing.JMenuItem smnuReportMedicamentosSimp;
    private javax.swing.JMenuItem smnuSede;
    private javax.swing.JMenuItem smnuUbigeo;
    // End of variables declaration//GEN-END:variables
}
