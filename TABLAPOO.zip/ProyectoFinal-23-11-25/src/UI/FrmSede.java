
package UI;

import BEAN.Sede;
import BEAN.Ubigeo;
import DAO.SedeDAO;
import DAO.UbigeoDAO;
import UTIL.Util;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class FrmSede extends javax.swing.JInternalFrame {

    SedeDAO sedDao;
    UbigeoDAO ubiDao;
    DefaultTableModel dtm;
    int idSede;

    public FrmSede() {
        sedDao = new SedeDAO();
        ubiDao = new UbigeoDAO();
        initComponents();

        dtm = (DefaultTableModel) this.tblSede.getModel();
        llenaTblSede("");

        // IDs y descripción de Ubigeo solo lectura
        this.txtIdSede.setEnabled(false);
        this.txtIdUbigeo.setEnabled(false);
        this.txtDescripcionUbigeo.setEnabled(false);
    }

    // ==================  MÉTODOS DE LÓGICA  ==================

    private void llenaTblSede(String cad) {
        Vector<Sede> listaSed;
        listaSed = sedDao.listaSedes(cad);
        dtm.setRowCount(0);
        for (int i = 0; i < listaSed.size(); i++) {
            Sede sed = listaSed.get(i);
            Vector vec = new Vector();
            vec.addElement(sed.getSedeID());                 // 0 SedeID
            vec.addElement(sed.getUbigeoId());               // 1 ID Ubigeo
            vec.addElement(descripcionUbigeoPorId(sed.getUbigeoId())); // 2 Desc. Ubigeo
            vec.addElement(sed.getNombSede());               // 3 Nombre Sede
            vec.addElement(sed.getDireccion());              // 4 Dirección
            vec.addElement(sed.getTlf());                    // 5 Teléfono
            dtm.addRow(vec);
        }
    }
    
    // Método público para que el buscador pueda llenar los campos
    public void setUbigeoSeleccionado(int idUbigeo, String descUbigeo) {
        this.txtIdUbigeo.setText(String.valueOf(idUbigeo));
        this.txtDescripcionUbigeo.setText(descUbigeo);
    }



    // Devuelve: "Departamento - Provincia - Distrito" para un UbigeoId
    private String descripcionUbigeoPorId(int idUbi) {
        Vector<Ubigeo> listaUbi = ubiDao.listaUbigeos("");
        for (int i = 0; i < listaUbi.size(); i++) {
            Ubigeo u = listaUbi.get(i);
            if (u.getUbigeoId() == idUbi) {
                return u.getDepartamento() + " - "
                        + u.getProvincia() + " - "
                        + u.getDistrito();
            }
        }
        return "";
    }

    private boolean valida() {
        boolean sw = false;
        String cad = "";

        if (this.txtIdUbigeo.getText().isEmpty()) {
            cad = "Debe seleccionar un Ubigeo (usar el botón BUSCAR UBIGEO)";
        }
        if (this.txtNombSede.getText().isEmpty()) {
            cad += "\nDebe registrar el nombre de la sede";
        }
        if (this.txtDireccion.getText().isEmpty()) {
            cad += "\nDebe registrar la dirección";
        }
        if (this.txtTlf.getText().isEmpty()) {
            cad += "\nDebe registrar el teléfono";
        }

        if (cad.isEmpty()) {
            sw = true;
        } else {
            JOptionPane.showMessageDialog(this, cad);
        }
        return sw;
    }

    private void limpia() {
        this.txtIdSede.setText("");
        this.txtIdUbigeo.setText("");
        this.txtDescripcionUbigeo.setText("");
        this.txtNombSede.setText("");
        this.txtDireccion.setText("");
        this.txtTlf.setText("");
        this.txtBuscar.setText("");
        this.btnGrabar.setText("Grabar");
        this.tblSede.clearSelection();
        idSede = 0;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnGrabar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        txtIdSede = new javax.swing.JTextField();
        txtIdUbigeo = new javax.swing.JTextField();
        txtDescripcionUbigeo = new javax.swing.JTextField();
        txtNombSede = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtTlf = new javax.swing.JTextField();
        btnBuscarUbigeo = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSede = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("MANTENIMIENTO SEDE");

        jLabel2.setText("Id Sede");

        jLabel3.setText("Id Ubigeo");

        jLabel4.setText("Descripcion Ubigeo");

        jLabel5.setText("Nombre Sede");

        jLabel6.setText("Dirección");

        jLabel7.setText("Telefono");

        btnGrabar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnGrabar.setText("Grabar");
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnSalir.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        txtIdUbigeo.setEnabled(false);

        txtDescripcionUbigeo.setEnabled(false);

        btnBuscarUbigeo.setText("BUSCAR UBIGEO");
        btnBuscarUbigeo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarUbigeoActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel8.setText("BUSCAR:");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(40, 30, 44, 14);

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        jPanel1.add(txtBuscar);
        txtBuscar.setBounds(130, 20, 410, 20);

        tblSede.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "SedeID", "ID Ubigeo", "Desc. Ubigeo", "NombSede", "Dirección", "Telefono"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSede.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSedeMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSede);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(30, 60, 520, 230);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(btnGrabar)
                .addGap(283, 283, 283)
                .addComponent(btnLimpiar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(187, 187, 187))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel6)))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtIdSede)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtIdUbigeo, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(btnBuscarUbigeo))
                            .addComponent(txtDescripcionUbigeo)
                            .addComponent(txtNombSede)
                            .addComponent(txtDireccion)
                            .addComponent(txtTlf, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(46, 46, 46)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 565, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(393, 393, 393)
                        .addComponent(jLabel1)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(txtIdSede, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtIdUbigeo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscarUbigeo))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtDescripcionUbigeo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtNombSede, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtTlf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGrabar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnSalir))
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        if (this.txtBuscar.getText().isEmpty()) {
            this.llenaTblSede("");
        } else {
            this.llenaTblSede(this.txtBuscar.getText());
        }
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
        if (valida() == true) {
            Util util = new Util();
            Sede sed = new Sede();
            String msj;

            sed.setUbigeoId(Integer.parseInt(this.txtIdUbigeo.getText()));
            sed.setNombSede(this.txtNombSede.getText());
            sed.setDireccion(this.txtDireccion.getText());
            sed.setTlf(this.txtTlf.getText());

            if (this.btnGrabar.getText().equals("Grabar")) {
                idSede = util.idNext("Sede", "SedeID");
                sed.setSedeID(idSede);
                this.sedDao.insertaSede(sed);
                msj = "Sede registrada exitosamente";
            } else {
                sed.setSedeID(idSede);
                this.sedDao.actualizaSede(sed);
                msj = "Sede actualizada exitosamente";
            }

            JOptionPane.showMessageDialog(this, msj);
            this.llenaTblSede("");
            limpia();
        }
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void tblSedeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSedeMouseClicked
        int idx;
        idx = this.tblSede.getSelectedRow();
        this.idSede = Integer.parseInt(dtm.getValueAt(idx, 0).toString());

        this.txtIdSede.setText(dtm.getValueAt(idx, 0).toString());
        this.txtIdUbigeo.setText(dtm.getValueAt(idx, 1).toString());
        this.txtDescripcionUbigeo.setText(dtm.getValueAt(idx, 2).toString());
        this.txtNombSede.setText(dtm.getValueAt(idx, 3).toString());
        this.txtDireccion.setText(dtm.getValueAt(idx, 4).toString());
        this.txtTlf.setText(dtm.getValueAt(idx, 5).toString());

        this.btnGrabar.setText("Actualizar");
    }//GEN-LAST:event_tblSedeMouseClicked

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
    limpia();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
    this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnBuscarUbigeoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarUbigeoActionPerformed
     SelectUbigeo frm = new SelectUbigeo(this);  // this = FrmSede
    frm.setLocationRelativeTo(this);
    frm.setVisible(true);
    }//GEN-LAST:event_btnBuscarUbigeoActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarUbigeo;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblSede;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDescripcionUbigeo;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtIdSede;
    private javax.swing.JTextField txtIdUbigeo;
    private javax.swing.JTextField txtNombSede;
    private javax.swing.JTextField txtTlf;
    // End of variables declaration//GEN-END:variables
}
