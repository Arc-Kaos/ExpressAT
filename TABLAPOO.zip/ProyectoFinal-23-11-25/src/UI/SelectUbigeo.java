
package UI;

import BEAN.Ubigeo;
import DAO.UbigeoDAO;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;


public class SelectUbigeo extends javax.swing.JFrame {

    UbigeoDAO ubiDao;
    DefaultTableModel dtm;

    // Ventana padre (FrmSede)
    FrmSede frmSede;

    // Constructor para pruebas (cuando lo abres solo)
    public SelectUbigeo() {
        this(null);
    }

    // Constructor que se usará desde FrmSede
    public SelectUbigeo(FrmSede frm) {
        initComponents();
        this.frmSede = frm;

        ubiDao = new UbigeoDAO();
        dtm = (DefaultTableModel) this.tblUbigeo.getModel();

        llenaTblUbigeo("");
        
    }
    
private void llenaTblUbigeo(String cad) {
    Vector<Ubigeo> listaUbi = ubiDao.listaUbigeos(cad);
    dtm.setRowCount(0);
    for (Ubigeo u : listaUbi) {
        Vector fila = new Vector();
        fila.add(u.getUbigeoId());
        fila.add(u.getRegion());
        fila.add(u.getDepartamento());
        fila.add(u.getProvincia());
        fila.add(u.getDistrito());
        dtm.addRow(fila);
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblUbigeo = new javax.swing.JTable();
        btnAceptar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Buscar:");

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        tblUbigeo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "UbigeoID", "Region", "Departamento", "Provincia", "Distrito"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblUbigeo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblUbigeoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblUbigeo);

        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 585, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(95, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(btnAceptar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCancelar)
                .addGap(165, 165, 165))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAceptar)
                    .addComponent(btnCancelar))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
        int fila = this.tblUbigeo.getSelectedRow();
        if (fila == -1) {
            // No hay fila seleccionada, no hacemos nada
            return;
        }

        int idUbi      = Integer.parseInt(dtm.getValueAt(fila, 0).toString());
        String region  = dtm.getValueAt(fila, 1).toString();
        String depa    = dtm.getValueAt(fila, 2).toString();
        String prov    = dtm.getValueAt(fila, 3).toString();
        String dist    = dtm.getValueAt(fila, 4).toString();

        String desc = region + " - " + depa + " - " + prov + " - " + dist;

        // Solo si nos llamaron desde FrmSede
        if (frmSede != null) {
            frmSede.setUbigeoSeleccionado(idUbi, desc);
        }

        this.dispose();
    }//GEN-LAST:event_btnAceptarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        if (this.txtBuscar.getText().isEmpty()) {
            llenaTblUbigeo("");
        } else {
            llenaTblUbigeo(this.txtBuscar.getText());
        }
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void tblUbigeoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblUbigeoMouseClicked
                                    
        if (evt.getClickCount() == 2) {
            btnAceptarActionPerformed(null);  // reutilizamos la misma lógica
        }
    }//GEN-LAST:event_tblUbigeoMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAceptar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblUbigeo;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
