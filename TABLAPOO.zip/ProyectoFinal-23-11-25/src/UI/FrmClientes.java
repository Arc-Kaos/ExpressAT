
package UI;

import BEAN.Clientes;
import DAO.ClientesDAO;
import UTIL.Util;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmClientes extends javax.swing.JInternalFrame {
    ClientesDAO clienDao;
    DefaultTableModel dtm;
    int idClient;
    public FrmClientes() {
        clienDao = new ClientesDAO();
        initComponents();
        llenaCmbGenero();
        llenaCmbEstCivil();
        llenaCmbEstado();
        dtm = (DefaultTableModel)this.tblClientes.getModel();
        
        llenaTblClientes("");
    }
private void llenaCmbGenero(){
        this.cmbGenero.addItem("");
        this.cmbGenero.addItem("Masculino");
        this.cmbGenero.addItem("Femenino");
               
}
private void llenaCmbEstCivil(){
        this.cmbEstCivil.addItem("");
        this.cmbEstCivil.addItem("Soltero");
        this.cmbEstCivil.addItem("Soltera");
        this.cmbEstCivil.addItem("Casado");
        this.cmbEstCivil.addItem("Casada");
        this.cmbEstCivil.addItem("Divorciado");
        this.cmbEstCivil.addItem("Divorciada");
        this.cmbEstCivil.addItem("Viudo");
        this.cmbEstCivil.addItem("Viuda");
                
    }
private void llenaCmbEstado(){
        this.cmbEstado.addItem("");
        this.cmbEstado.addItem("Activo");
        this.cmbEstado.addItem("No Activo");
    }
private void llenaTblClientes(String cad){
        Vector<Clientes> listaClient;
        listaClient = clienDao.listaCliente(cad);
        dtm.setRowCount(0);
        for(int i=0;i<listaClient.size();i++){
            Vector vec = new Vector();
            vec.addElement(listaClient.get(i).getClienteID());
            vec.addElement(listaClient.get(i).getNombre());
            vec.addElement(listaClient.get(i).getApellido());
            vec.addElement(listaClient.get(i).getDireccion());
            vec.addElement(listaClient.get(i).getTelefono());
            vec.addElement(listaClient.get(i).getDNI());
            
            if(listaClient.get(i).getGenero()==1){
                vec.addElement("Masculino");
            }else{
                vec.addElement("Femenino");
            }   
            
            if(listaClient.get(i).getEstCivil() == 1){
                vec.addElement("Soltero");
            }else if(listaClient.get(i).getEstCivil() == 2){
                vec.addElement("Soltera");    
            }else if(listaClient.get(i).getEstCivil() == 3){
                vec.addElement("Casado");
            }else if(listaClient.get(i).getEstCivil() == 4){
                vec.addElement("Casada");
            }else if(listaClient.get(i).getEstCivil() == 5){
                vec.addElement("Divorciado");
            }else if(listaClient.get(i).getEstCivil() == 6){
                vec.addElement("Divorciada");    
            }else if(listaClient.get(i).getEstCivil() == 7){
                vec.addElement("Viudo");
            }else if(listaClient.get(i).getEstCivil() == 8){
                vec.addElement("Viuda");
            }

            if(listaClient.get(i).getEstado()==1){
                vec.addElement("Activo");
            }else{
                vec.addElement("No Activo");
            }
            
            
            dtm.addRow(vec);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtClienteID = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtDNI = new javax.swing.JTextField();
        btnGrabar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        cmbEstado = new javax.swing.JComboBox<String>();
        cmbEstCivil = new javax.swing.JComboBox<String>();
        cmbGenero = new javax.swing.JComboBox<String>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("ClienteID");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 0, 0));
        jLabel2.setText("MANTENIMIENTO CLIENTES");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Apellido");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Direccion");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Telefono");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("DNI");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel11.setText("BUSCAR");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(70, 30, 70, 20);

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        jPanel1.add(txtBuscar);
        txtBuscar.setBounds(160, 20, 500, 40);

        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ClienteID", "Nombre", "Apellido", "Direccion", "Telefono", "DNI", "Genero", "EstCivil", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblClientes);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(40, 80, 760, 240);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Genero");

        jLabel9.setText("EstCivil");

        jLabel10.setText("Estado");

        txtClienteID.setEnabled(false);

        btnGrabar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnGrabar.setText("GRABAR");
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnSalir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel4)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel8)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel9))))))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtClienteID)
                    .addComponent(txtNombre)
                    .addComponent(txtApellido)
                    .addComponent(txtDireccion)
                    .addComponent(txtTelefono)
                    .addComponent(txtDNI)
                    .addComponent(cmbEstado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbEstCivil, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbGenero, 0, 125, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(btnGrabar)
                        .addGap(154, 154, 154)
                        .addComponent(btnLimpiar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 225, Short.MAX_VALUE)
                        .addComponent(btnSalir)
                        .addGap(130, 130, 130))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGap(260, 260, 260)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel2)
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtClienteID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cmbGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cmbEstCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnGrabar)
                            .addComponent(btnLimpiar)
                            .addComponent(btnSalir))
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
       if(valida()== true){
            Util util = new Util();
            Clientes clien = new Clientes();
            String msj;
            clien.setNombre(this.txtNombre.getText());
            clien.setApellido(this.txtApellido.getText());
            clien.setDireccion(this.txtDireccion.getText());
            clien.setTelefono(this.txtTelefono.getText());
            clien.setDNI(this.txtDNI.getText());
            
            if(this.cmbGenero.getSelectedItem().toString().equals("Masculino")){
                clien.setGenero(1);
            }else{
                clien.setGenero(0);
            }
            if(this.cmbEstCivil.getSelectedItem().toString().equals("Soltero")){
                clien.setEstCivil(1);
            }else if(this.cmbEstCivil.getSelectedItem().toString().equals("Soltera")){
                clien.setEstCivil(2);
            }else if(this.cmbEstCivil.getSelectedItem().toString().equals("Casado")){
                clien.setEstCivil(3);
            }else if(this.cmbEstCivil.getSelectedItem().toString().equals("Casada")){
                clien.setEstCivil(4);
            }else if(this.cmbEstCivil.getSelectedItem().toString().equals("Divorciado")){
                clien.setEstCivil(5);
            }else if(this.cmbEstCivil.getSelectedItem().toString().equals("Divorciada")){
                clien.setEstCivil(6);
            }else if(this.cmbEstCivil.getSelectedItem().toString().equals("Viudo")){
                clien.setEstCivil(7);
            }else if(this.cmbEstCivil.getSelectedItem().toString().equals("Viuda")){
                clien.setEstCivil(8);
            }
                    
            if(this.cmbEstado.getSelectedItem().toString().equals("Activo")){
                clien.setEstado(1);
            }else{
                clien.setEstado(0);
            }
            if(this.btnGrabar.getText().equals("Grabar")){
                idClient = util.idNext("Clientes", "ClienteID");
                clien.setClienteID(idClient);
                this.clienDao.insertaCliente(clien);
                msj = "Cliente registrado exitosamente";
            }else{
                clien.setClienteID(idClient);
                this.clienDao.actualizaCliente(clien);
                msj = "Cliente actualizado exitosamente";
            }
            JOptionPane.showMessageDialog(this, msj);
            this.llenaTblClientes("");
            limpia();
        }
        
    }                                         
private boolean valida(){
        boolean sw = false;
        String cad = "";
        if(this.txtNombre.getText().isEmpty()){
            cad += "Debe registrar el nombre";
        }
        if(this.txtApellido.getText().isEmpty()){
            cad += "\nDebe registrar el apellido";
        }
        if(this.txtDireccion.getText().isEmpty()){
            cad += "\nDebe registrar la direccion";
        }
        if(this.txtTelefono.getText().isEmpty()){
            cad += "\nDebe registrar el telefono";
        }
        if(this.txtDNI.getText().isEmpty()){
            cad += "\nDebe registrar el DNI";
        }
        if(this.cmbGenero.getSelectedItem().toString().isEmpty()){
            cad += "\nDebe seleccionar el tipo de genero";
        }/*
        if(this.cmbEstCivil.getSelectedItem().toString().isEmpty()){
            cad += "Debe seleccionar el estado civil";
        }  
        if(this.cmbEstado.getSelectedItem().toString().isEmpty()){
            cad += "\nDebe seleccionar el estado del cliente";
        }*/
        if(cad.isEmpty()){
            sw = true;
        }else{
            JOptionPane.showMessageDialog(this, cad);
        }
        return sw; 
 
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void tblClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblClientesMouseClicked
      int idx;
        idx = this.tblClientes.getSelectedRow();
        this.idClient = Integer.parseInt(dtm.getValueAt(idx, 0).toString());
        this.txtClienteID.setText(dtm.getValueAt(idx, 0).toString());
        this.txtNombre.setText(dtm.getValueAt(idx, 1).toString());
        this.txtApellido.setText(dtm.getValueAt(idx, 2).toString());
        this.txtDireccion.setText(dtm.getValueAt(idx, 3).toString());
        this.txtTelefono.setText(dtm.getValueAt(idx, 4).toString());
        this.txtDNI.setText(dtm.getValueAt(idx, 5).toString());
        this.cmbGenero.setSelectedItem(dtm.getValueAt(idx, 6).toString());
        this.cmbEstCivil.setSelectedItem(dtm.getValueAt(idx, 7).toString());
        this.cmbEstado.setSelectedItem(dtm.getValueAt(idx, 8).toString());
        this.btnGrabar.setText("Actualizar");  
        
    }//GEN-LAST:event_tblClientesMouseClicked

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
       if(this.txtBuscar.getText().isEmpty()){
            this.llenaTblClientes("");
        }else{
            this.llenaTblClientes(this.txtBuscar.getText());
        }
        
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
       this.limpia();
    }//GEN-LAST:event_btnLimpiarActionPerformed
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed
private void limpia(){
        this.txtClienteID.setText("");
        this.txtNombre.setText("");
        this.txtApellido.setText("");
        this.txtDireccion.setText("");
        this.txtTelefono.setText("");
        this.txtDNI.setText("");
        this.cmbGenero.setSelectedItem("");
        this.cmbEstCivil.setSelectedItem("");
        this.cmbEstado.setSelectedItem("");
        this.btnGrabar.setText("Grabar");
    }

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<String> cmbEstCivil;
    private javax.swing.JComboBox<String> cmbEstado;
    private javax.swing.JComboBox<String> cmbGenero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtClienteID;
    private javax.swing.JTextField txtDNI;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
