package UTIL;

import java.sql.ResultSet;

public class Util {

    public Util(){}

    public int idNext(String nombTbl, String nombCamp){
        DbBean con = new DbBean();
        int countReg = 0, idNuevo = 0;

        try {
            String sql = "SELECT COUNT(" + nombCamp + ") FROM " + nombTbl;
            ResultSet rs = con.execSQL(sql);

            if(rs.next()){
                countReg = rs.getInt(1);
            }
            rs.close();

            if(countReg > 0){
                sql = "SELECT MAX(" + nombCamp + ") FROM " + nombTbl;
                ResultSet rs2 = con.execSQL(sql);
                if(rs2.next()){
                    idNuevo = rs2.getInt(1) + 1;
                }
                rs2.close();
            } else {
                idNuevo = 1;
            }

        } catch (Exception e){
            e.printStackTrace();
        }
        return idNuevo;
    }

    public boolean repExp(String nombTbl, String nombCamp, String cad){
        DbBean con = new DbBean();
        boolean existe = false;

        try {
            String sql = "SELECT 1 FROM "+ nombTbl +" WHERE "+ nombCamp +" = '"+ cad +"'";
            ResultSet rs = con.execSQL(sql);
            existe = rs.next();
            rs.close();
        } catch(Exception e){
            e.printStackTrace();
        }
        return existe;
    }

    public String cadExp(String nombTbl, String campID, String nomCampBusq, String cad){
        DbBean con = new DbBean();
        String valor = "";

        try{
            String sql = "SELECT "+ nomCampBusq +" FROM "+ nombTbl +" WHERE "+ campID +" = '"+ cad +"'";
            ResultSet rs = con.execSQL(sql);
            if(rs.next()){
                valor = rs.getString(1);
            }
            rs.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return valor;
    }

    public int idExp(String nombTbl, String campID, String nomCampBusq, String cad){
        DbBean con = new DbBean();
        int id = 0;

        try{
            String sql = "SELECT "+ campID +" FROM "+ nombTbl +" WHERE "+ nomCampBusq +" = '"+ cad +"'";
            ResultSet rs = con.execSQL(sql);
            if(rs.next()){
                id = rs.getInt(1);
            }
            rs.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return id;
    }

    public String obtenerFecha(){
        DbBean con = new DbBean();
        String fecha = "";

        try{
            ResultSet rs = con.execSQL("SELECT GETDATE()");
            if(rs.next()){
                fecha = rs.getString(1);
            }
            rs.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return fecha;
    }

    public int numRows(String sql){
        DbBean con = new DbBean();
        int nR = 0;

        try{
            ResultSet rs = con.execSQL("SELECT COUNT(*) FROM ("+ sql +") AS X");
            if(rs.next()){
                nR = rs.getInt(1);
            }
            rs.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return nR;
    }
}
