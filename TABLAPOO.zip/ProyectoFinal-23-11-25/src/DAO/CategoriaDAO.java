package DAO;

import BEAN.Categoria;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class CategoriaDAO {

    public Vector<Categoria> listaCategoria(boolean sw, String cad){
        DbBean con = new DbBean();
        Vector<Categoria> listaCat = new Vector<>();
        String sql = "select * from Categoria ";
        if(sw){
            sql += " where DescCategoria like '" + cad + "%'";
        }
        try{
            ResultSet result = con.execSQL(sql);
            while(result.next()){
                Categoria c = new Categoria();
                c.setCategoriaID(result.getInt(1));
                c.setDescCategoria(result.getString(2));
                c.setObs(result.getString(3));
                listaCat.addElement(c);
            }
            con.close();
        }catch(Exception e){}
        return listaCat;
    }

    public void insertaCategoria(Categoria c){
        DbBean con = new DbBean();
        String sql = "insert into Categoria values(" + c.getCategoriaID() + ", '" +
                     c.getDescCategoria() + "', '" + c.getObs() + "')";
        try{
            con.updateSQL(sql);
            con.close();
        }catch(Exception e){}
    }

    public void actualizaCategoria(Categoria c){
        DbBean con = new DbBean();
        String sql = "update Categoria set DescCategoria = '" + c.getDescCategoria() +
                     "', Obs = '" + c.getObs() +
                     "' where CategoriaID = " + c.getCategoriaID();
        try{
            con.updateSQL(sql);
            con.close();
        }catch(Exception e){}
    }

    public void eliminaCategoria(int id){
        DbBean con = new DbBean();
        String sql = "delete from Categoria where CategoriaID = " + id;
        try{
            con.updateSQL(sql);
            con.close();
        }catch(Exception e){}
    }
}
