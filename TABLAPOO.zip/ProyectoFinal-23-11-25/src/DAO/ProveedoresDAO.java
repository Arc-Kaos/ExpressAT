package DAO;

import BEAN.Proveedores;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class ProveedoresDAO {

    public Vector<Proveedores> listaProveedores(boolean sw, String cad){
        DbBean con = new DbBean();
        Vector<Proveedores> lista = new Vector<>();

        String sql = "select * from Proveedores";
        if(sw){
            sql += " where Nombre like '" + cad + "%'";
        }

        try{
            ResultSet result = con.execSQL(sql);

            while(result.next()){
                Proveedores p = new Proveedores();
                p.setProveedorID(result.getInt("ProveedorID"));
                p.setNombre(result.getString("Nombre"));
                p.setNombreContacto(result.getString("NombreContacto"));
                p.setDireccion(result.getString("Direccion"));
                p.setCiudad(result.getString("Ciudad"));
                p.setTelefono(result.getString("Telefono"));
                p.setEstado(result.getInt("Estado"));

                lista.add(p);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        try{ con.close(); }catch(Exception e){}
        return lista;
    }

    public void insertaProveedor(Proveedores p){
        DbBean con = new DbBean();
        String sql = "insert into Proveedores values("
                + p.getProveedorID() + ", '"
                + p.getNombre() + "', '"
                + p.getNombreContacto() + "', '"
                + p.getDireccion() + "', '"
                + p.getCiudad() + "', '"
                + p.getTelefono() + "', "
                + p.getEstado() + ")";

        try{
            con.updateSQL(sql);
            System.out.println("SQL INSERT Proveedor: " + sql);
        }catch(Exception e){
            e.printStackTrace();
        }

        try{ con.close(); }catch(Exception e){}
    }

    public void actualizaProveedor(Proveedores p){
        DbBean con = new DbBean();
        String sql = "update Proveedores set "
                + "Nombre = '" + p.getNombre() + "', "
                + "NombreContacto = '" + p.getNombreContacto() + "', "
                + "Direccion = '" + p.getDireccion() + "', "
                + "Ciudad = '" + p.getCiudad() + "', "
                + "Telefono = '" + p.getTelefono() + "', "
                + "Estado = " + p.getEstado() + " "
                + "where ProveedorID = " + p.getProveedorID();

        try{
            con.updateSQL(sql);
            System.out.println("SQL UPDATE Proveedor: " + sql);
        }catch(Exception e){
            e.printStackTrace();
        }

        try{ con.close(); }catch(Exception e){}
    }
}
