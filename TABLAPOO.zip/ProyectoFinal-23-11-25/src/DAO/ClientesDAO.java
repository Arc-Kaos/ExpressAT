package DAO;

import BEAN.Clientes;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class ClientesDAO {

    public Vector<Clientes> listaCliente(String cad){
        Vector<Clientes> listaClien = new Vector<>();
        DbBean con = new DbBean();
        String sql = "select * from Clientes";
        if(!cad.isEmpty()){
            sql += " where Nombre like '" + cad + "%'";
        }
        try{
            ResultSet resultado = con.execSQL(sql);
            while(resultado.next()){
                Clientes clien = new Clientes();
                clien.setClienteID(resultado.getInt(1));
                clien.setNombre(resultado.getString(2));
                clien.setApellido(resultado.getString(3));
                clien.setDireccion(resultado.getString(4));
                clien.setTelefono(resultado.getString(5));
                clien.setDNI(resultado.getString(6));
                clien.setGenero(resultado.getInt(7));
                clien.setEstCivil(resultado.getInt(8));
                clien.setEstado(resultado.getInt(9));
                listaClien.addElement(clien);
            }
            con.close();
        }catch(Exception e){}
        return listaClien;
    }

    public void insertaCliente(Clientes clie){
        DbBean con = new DbBean();
        String sql = "insert into clientes values(" +
                     clie.getClienteID() + ", '" +
                     clie.getNombre() + "', '" +
                     clie.getApellido() + "', '" +
                     clie.getDireccion() + "', '" +
                     clie.getTelefono() + "', '" +
                     clie.getDNI() + "', " +
                     clie.getGenero() + ", " +
                     clie.getEstCivil() + ", " +
                     clie.getEstado() + ")";
        try{
            con.updateSQL(sql);
            con.close();
        }catch(Exception e){}
    }

    public void actualizaCliente(Clientes clie){
        DbBean con = new DbBean();
        String sql = "update clientes set Nombre = '" + clie.getNombre() +
                     "', Apellido = '" + clie.getApellido() +
                     "', Direccion = '" + clie.getDireccion() +
                     "', Telefono = '" + clie.getTelefono() +
                     "', DNI = '" + clie.getDNI() +
                     "', Genero = " + clie.getGenero() +
                     ", EstCivil = " + clie.getEstCivil() +
                     ", Estado = " + clie.getEstado() +
                     " where ClienteID = " + clie.getClienteID();
        try{
            con.updateSQL(sql);
            con.close();
        }catch(Exception e){}
    }
}
