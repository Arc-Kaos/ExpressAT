package DAO;

import BEAN.Ubigeo;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class UbigeoDAO {

    public Vector<Ubigeo> listaUbigeos(String cad){
        DbBean con = new DbBean();
        Vector<Ubigeo> lista = new Vector<>();
        String sql = "select * from Ubigeo";

        if(!cad.isEmpty()){
            sql += " where Departamento like '" + cad + "%' " +
                   "or Provincia like '" + cad + "%' " +
                   "or Distrito like '" + cad + "%'";
        }

        try{
            ResultSet rs = con.execSQL(sql);
            while(rs.next()){
                Ubigeo u = new Ubigeo();
                u.setUbigeoId(rs.getInt(1));
                u.setRegion(rs.getString(2));
                u.setDepartamento(rs.getString(3));
                u.setProvincia(rs.getString(4));
                u.setDistrito(rs.getString(5));
                lista.add(u);
            }
        }catch(Exception e){ e.printStackTrace(); }

        try{ con.close(); }catch(Exception e){}
        return lista;
    }

    public void insertaUbigeo(Ubigeo u){
        DbBean con = new DbBean();
        String sql = "insert into Ubigeo values(" +
                u.getUbigeoId() + ", '" +
                u.getRegion() + "', '" +
                u.getDepartamento() + "', '" +
                u.getProvincia() + "', '" +
                u.getDistrito() + "')";

        try{ con.updateSQL(sql); }catch(Exception e){}
        try{ con.close(); }catch(Exception e){}
    }

    public void actualizaUbigeo(Ubigeo ubi){
        DbBean con = new DbBean();
        String sql = "update Ubigeo set Region='" + ubi.getRegion() +
                "', Departamento='" + ubi.getDepartamento() +
                "', Provincia='" + ubi.getProvincia() +
                "', Distrito='" + ubi.getDistrito() +
                "' where UbigeoId=" + ubi.getUbigeoId();

        try{ con.updateSQL(sql); }catch(Exception e){}
        try{ con.close(); }catch(Exception e){}
    }
}
