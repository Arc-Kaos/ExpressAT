package DAO;

import BEAN.Medicamentos;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class MedicamentosDAO {

    public Vector<Medicamentos> listaMedicamentos(boolean sw, String cad){
        DbBean con = new DbBean();
        Vector<Medicamentos> lista = new Vector<>();
        String sql = "SELECT * FROM Medicamentos";

        if(sw){
            sql += " WHERE Nombre LIKE '" + cad + "%'";
        }

        try{
            ResultSet result = con.execSQL(sql);

            while(result.next()){
                Medicamentos med = new Medicamentos();
                med.setMedicamentoID(result.getInt(1));
                med.setCategoriaID(result.getInt(2));
                med.setProveedorID(result.getInt(3));
                med.setNombre(result.getString(4));
                med.setDescripcion(result.getString(5));
                med.setPrecio(result.getDouble(6));
                med.setStock(result.getInt(7));
                med.setFechaExpiracion(result.getString(8));

                lista.add(med);
            }

        } catch(Exception e){
            e.printStackTrace();
        } finally {
            try { con.close(); } catch(Exception e){}
        }

        return lista;
    }


    public void insertaMedicamento(Medicamentos med){
        DbBean con = new DbBean();

        String sql = "INSERT INTO Medicamentos VALUES("
                + med.getMedicamentoID() + ", "
                + med.getCategoriaID() + ", "
                + med.getProveedorID() + ", '"
                + med.getNombre() + "', '"
                + med.getDescripcion() + "', "
                + med.getPrecio() + ", "
                + med.getStock() + ", '"
                + med.getFechaExpiracion() + "')";

        try{
            System.out.println("SQL INSERT: " + sql);
            con.updateSQL(sql);
        } catch(Exception e){
            e.printStackTrace();
        } finally {
            try { con.close(); } catch(Exception e){}
        }
    }


    public void actualizaMedicamento(Medicamentos m){
        DbBean con = new DbBean();

        String sql = "UPDATE Medicamentos SET "
                + "Nombre = '" + m.getNombre() + "', "
                + "Descripcion = '" + m.getDescripcion() + "', "
                + "Precio = " + m.getPrecio() + ", "
                + "Stock = " + m.getStock() + ", "
                + "FechaExpiracion = '" + m.getFechaExpiracion() + "' "
                + "WHERE MedicamentoID = " + m.getMedicamentoID();

        try{
            System.out.println("SQL UPDATE: " + sql);
            con.updateSQL(sql);
        } catch(Exception e){
            e.printStackTrace();
        } finally {
            try { con.close(); } catch(Exception e){}
        }
    }

}
