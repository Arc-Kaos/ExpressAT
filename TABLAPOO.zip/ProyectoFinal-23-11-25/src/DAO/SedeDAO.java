package DAO;

import BEAN.Sede;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class SedeDAO {

    public Vector<Sede> listaSedes(String cad){
        Vector<Sede> lista = new Vector<>();
        DbBean con = new DbBean();
        String sql = "select * from Sede";

        if(!cad.isEmpty()){
            sql += " where NombSede like '" + cad + "%'";
        }

        try{
            ResultSet rs = con.execSQL(sql);
            while(rs.next()){
                Sede s = new Sede();
                s.setSedeID(rs.getInt(1));
                s.setUbigeoId(rs.getInt(2));
                s.setNombSede(rs.getString(3));
                s.setDireccion(rs.getString(4));
                s.setTlf(rs.getString(5));
                lista.add(s);
            }
        }catch(Exception e){ e.printStackTrace(); }

        try{ con.close(); }catch(Exception e){}
        return lista;
    }

    public void insertaSede(Sede sed){
        DbBean con = new DbBean();
        String sql = "insert into Sede values(" +
                sed.getSedeID() + ", " +
                sed.getUbigeoId() + ", '" +
                sed.getNombSede() + "', '" +
                sed.getDireccion() + "', '" +
                sed.getTlf() + "')";

        try{
            con.updateSQL(sql);
        }catch(Exception e){}
        try{ con.close(); }catch(Exception e){}
    }

    public void actualizaSede(Sede sed){
        DbBean con = new DbBean();
        String sql = "update Sede set UbigeoId=" + sed.getUbigeoId() +
                ", NombSede='" + sed.getNombSede() +
                "', Direccion='" + sed.getDireccion() +
                "', Tlf='" + sed.getTlf() +
                "' where SedeID=" + sed.getSedeID();

        try{ con.updateSQL(sql); }catch(Exception e){}
        try{ con.close(); }catch(Exception e){}
    }
}
