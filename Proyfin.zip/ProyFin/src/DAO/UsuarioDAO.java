package DAO;

import BEAN.Usuario;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

public class UsuarioDAO {

    public UsuarioDAO() {
    }
    
    public Vector<Usuario> listaUser(String cad){
        ResultSet resultado;
        Vector<Usuario> listaUser;
        listaUser = new Vector<Usuario>();
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "select * from Usuario ";
            if(!cad.isEmpty()){
                sql = sql + " where Usuario like '"+ cad +"%'";
            }
            resultado = con.resultadoSQL(sql);
            while(resultado.next()){
                Usuario user = new Usuario();
                user.setUsuarioID(resultado.getInt(1));
                user.setEmpleadoID(resultado.getInt(2));
                user.setUsuario(resultado.getString(3));
                user.setPassword(resultado.getString(4));
                listaUser.addElement(user);
            }
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        
        
        return listaUser;
    }
    
    public void insertaUsuario(Usuario user){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "insert into Usuario values( ";
            sql = sql + ""+ user.getUsuarioID() +", ";
            sql = sql + ""+ user.getEmpleadoID() + ", ";
            sql = sql + "'"+ user.getUsuario() +"', ";
            sql = sql + "'"+ user.getPassword() +"')";
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void actualizaUsuario(Usuario user){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "update Usuario set ";
            sql += " EmpleadoID = "+ user.getEmpleadoID() +", ";
            sql += " Usuario = '"+ user.getUsuario() +"', ";
            sql += " Password = '" + user.getPassword() + "' ";
            sql += " WHERE UsuarioID = "+ user.getUsuarioID() +" ";
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void eliminaUsuario(){
    }
}
    
    
    
  
