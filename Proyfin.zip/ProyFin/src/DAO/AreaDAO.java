package DAO;

import BEAN.Area;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

public class AreaDAO {
      public AreaDAO() {
    }
    
    public Vector<Area> listaAreas(String cad){
        ResultSet resultado;
        Vector<Area> listaAreas;
        listaAreas = new Vector<Area>();
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "select * from Area ";
            if(!cad.isEmpty()){
                sql += " WHERE DescArea LIKE '" + cad + "%' OR SubArea LIKE '" + cad + "%'";
            }
            resultado = con.resultadoSQL(sql);
            while(resultado.next()){
                Area areas = new Area();
                areas.setArea_ID(resultado.getInt(1));
                areas.setDescArea(resultado.getString(2));
                areas.setsubArea(resultado.getString(3));
                areas.setCentCosto(resultado.getDouble(4));
                listaAreas.addElement(areas);
            }
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        
        
        return listaAreas;
    }
    
    public void insertaAreas(Area areas){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "insert into Area values( ";
            sql = sql + ""+ areas.getArea_ID() +", ";
            sql = sql + "'"+ areas.getDescArea() + "', ";
            sql = sql + "'"+ areas.getsubArea() +"', ";
            sql = sql + ""+ areas.getCentCosto() +")";
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void actualizaArea(Area areas){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "update Area set ";
            sql += " DescArea = '"+ areas.getDescArea() +"', ";
            sql += " SubArea = '"+ areas.getsubArea() +"', ";
            sql += " centCosto = "+ areas.getCentCosto() +" ";
            sql += " WHERE AreaID = "+ areas.getArea_ID() +"";
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void eliminaArea(){
    }
}
   


