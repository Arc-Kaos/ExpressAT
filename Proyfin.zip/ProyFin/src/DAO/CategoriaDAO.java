package DAO;

import BEAN.Categoria;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

public class CategoriaDAO {

    public CategoriaDAO() {
    }
    
    public Vector<Categoria> listaCat(String cad){
        ResultSet resultado;
        Vector<Categoria> listaCat;
        listaCat = new Vector<Categoria>();
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "select * from Categoria ";
            if(!cad.isEmpty()){
                sql = sql + " where DescCategoria like '"+ cad +"%'";
            }
            resultado = con.resultadoSQL(sql);
            while(resultado.next()){
                Categoria cat = new Categoria();
                cat.setCategoriaID(resultado.getInt(1));
                cat.setDescCategoria(resultado.getString(2));
                cat.setObs(resultado.getString(3));
                listaCat.addElement(cat);
            }
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        
        
        return listaCat;
    }
    
    public void insertaCategoria(Categoria cat){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "insert into categoria values( ";
            sql = sql + ""+ cat.getCategoriaID() +", ";
            sql = sql + "'"+ cat.getDescCategoria() + "', ";
            sql += "'" + cat.getObs() + "')";
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void actualizaCategoria(Categoria cat){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "update Categoria set ";
            sql += " DescCategoria = '"+ cat.getDescCategoria() +"', ";
            sql += " Obs = '"+ cat.getObs() +"' ";
            sql += " where CategoriaID = "+ cat.getCategoriaID() +"";
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void eliminaCategoria(){
    }
}