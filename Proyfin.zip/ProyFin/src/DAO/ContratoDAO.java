
package DAO;
import DAO.AreaDAO;
import BEAN.*;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;
public class ContratoDAO {
    public ContratoDAO(){
    }
        public Vector<Contrato> listaCont(String cad){
        ResultSet resultado;
        Vector<Contrato> listaCont;
        listaCont = new Vector<Contrato>();
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "select * from Contrato ";
            if(!cad.isEmpty()){
                sql = sql + " where Fech_Ini like '"+ cad +"%'";
            }
            resultado = con.resultadoSQL(sql);
            while(resultado.next()){
                Contrato cont = new Contrato();
                cont.setContratoID(resultado.getInt("contratoID"));
                cont.setEmpleadoID(resultado.getInt("empleadoID"));
                cont.setFech_Ini(resultado.getDate("Fech_Ini").toLocalDate());
                cont.setFech_Fin(resultado.getDate("Fech_Fin").toLocalDate());
                cont.setAreaID(resultado.getInt("areaID"));
                cont.setRolID(resultado.getInt("rolID"));
                cont.setSueldo(resultado.getDouble("Sueldo"));
                cont.setSueldo(resultado.getInt("Estado"));
                listaCont.addElement(cont);
            }
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        
        
        return listaCont;
    }
    
    public void insertaCont(Contrato cont){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "insert into contrato values( ";
            sql += cont.getContratoID() + ", ";
            sql += cont.getEmpleadoID() + ", ";
            sql += "'" + cont.getFech_Ini().toString() + "', ";
            sql += "'" + cont.getFech_Fin().toString() + "', ";
            sql += cont.getAreaID() + ", ";
            sql += cont.getRolID() + ", ";
            sql += cont.getSueldo() + ", ";
            sql += cont.getEstado() + ")";
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void actualizaContrato(Contrato cont){
        DbBean con = new DbBean();
        String sql;
        try{
            sql = "update Contrato set ";
            sql += "empleadoID = " + cont.getEmpleadoID() + ", ";
            sql += "fech_Ini = '" + cont.getFech_Ini().toString() + "', ";
            sql += "fech_Fin = '" + cont.getFech_Fin().toString() + "', ";
            sql += "areaID = " + cont.getAreaID() + ", ";
            sql += "rolID = " + cont.getRolID() + ", ";
            sql += "sueldo = " + cont.getSueldo() + ", ";
            sql += "estado = " + cont.getEstado() + " ";
            sql += "WHERE contratoID = " + cont.getContratoID();
            con.ejecutaSQL(sql);
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
        try{
            con.desconecta();
        }catch(java.sql.SQLException e){
            e.printStackTrace();
        }
    }
    
    public void eliminaContrato(){
}
}