
package UI;
import BEAN.Contrato;
import UTIL.Util;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import DAO.ContratoDAO;
import java.time.LocalDate;

public class FrmContrato extends javax.swing.JFrame {
    ContratoDAO ContDao;
    DefaultTableModel dtm;
    int contID;
    public FrmContrato() {
        ContDao = new ContratoDAO();
        initComponents();
        dtm = (DefaultTableModel)this.tblContrato.getModel();
        llenaTblContrato("");
    }
     private void llenaCmbEstado(){
        this.cmbEstado.addItem("");
        this.cmbEstado.addItem("Activo");
        this.cmbEstado.addItem("No Activo");
     
     }
        private void llenaTblContrato(String cad){
        Vector<Contrato> listaConts;
        listaConts = ContDao.listaCont(cad);
        dtm.setRowCount(0);
        for(int i=0;i<listaConts.size();i++){
            Vector vec = new Vector();
            vec.addElement(listaConts.get(i).getContratoID());
            vec.addElement(listaConts.get(i).getEmpleadoID());
            vec.addElement(listaConts.get(i).getFech_Ini());
            vec.addElement(listaConts.get(i).getFech_Fin());
            vec.addElement(listaConts.get(i).getAreaID());
            vec.addElement(listaConts.get(i).getRolID());
            vec.addElement(listaConts.get(i).getSueldo());
            if(listaConts.get(i).getEstado()==1){
                vec.addElement("Activo");
            }else{
                vec.addElement("No Activo");
            }
            dtm.addRow(vec);
                if(listaConts.get(i).getEstado()==1){
                    vec.addElement("Activo");
                }else{
                    vec.addElement("No Activo");
                }
                dtm.addRow(vec);
                }
        }
        private boolean valida(){
            boolean sw = false;
            String cad = ""; 

            if(this.txtContratoID.getText().isEmpty()){
                cad += "\nDebe registrar el Id del contrato ";
        }
            if(this.txtEmpleadoID.getText().isEmpty()){
                cad += "Debe registrar correctamente el ID del Empleado"; // El primer error no necesita \n
        }
            if(this.txtFech_Ini.getText().isEmpty()){
                cad += "Debe registrar una fecha válida";
        }
            if(this.txtFechFin.getText().isEmpty()){
                cad += "\nDebe registrar una fecha válida";
        }
            if(this.txtAreaID.getText().isEmpty()){
                cad += "Debe registrar correctamente el ID del área"; // El primer error no necesita \n
        }
            if(this.txtRolID.getText().isEmpty()){
                cad += "Debe registrar un IDRol Válido";
        }
            if(this.txtSueldo.getText().isEmpty()){
                cad += "Debe registrar un sueldo Válido";
        }
    
        return sw;
        }   
        private void limpia(){
        this.txtContratoID.setText("");
        this.txtEmpleadoID.setText("");
        this.txtFech_Ini.setText("");
        this.txtFechFin.setText("");
        this.txtAreaID.setText("");
        this.txtRolID.setText("");
        this.txtSueldo.setText("");
        this.cmbEstado.setSelectedItem("");
        this.btnGrabar.setText("Grabar");
         }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        txtFechFin1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnGrabar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtFech_Ini = new javax.swing.JTextField();
        btnLimpiar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtContratoID = new javax.swing.JTextField();
        txtFechFin = new javax.swing.JTextField();
        btnSalir = new javax.swing.JButton();
        txtEmpleadoID = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblContrato = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        txtAreaID = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtRolID = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtSueldo = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        cmbEstado = new javax.swing.JComboBox<>();

        jLabel6.setText("Fech_Fin");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("ContratoID");

        btnGrabar.setText("Grabar");
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        jLabel3.setText("EmpleadoID");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("                    CONTRATOS");

        jLabel4.setText("Fech_Ini");

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        jLabel5.setText("Fech_Fin");

        btnSalir.setText("Salir");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel7.setText("Buscar");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(10, 20, 50, 14);

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        jPanel1.add(txtBuscar);
        txtBuscar.setBounds(70, 20, 310, 20);

        tblContrato.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "UsuarioID", "EmpleadoID", "Fech_Ini", "Fech_Fin", "AreaID", "RolID", "Sueldo", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblContrato.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblContratoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblContrato);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 50, 420, 170);

        jLabel8.setText("AreaID");

        jLabel9.setText("RolID");

        txtRolID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRolIDActionPerformed(evt);
            }
        });

        jLabel10.setText("Sueldo");

        txtSueldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSueldoActionPerformed(evt);
            }
        });

        jLabel11.setText("Estado");

        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtFech_Ini, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtFechFin, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtContratoID, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtAreaID, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(44, 44, 44)
                                        .addComponent(txtSueldo, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(18, 18, 18)
                                .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(118, 118, 118)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtRolID, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnGrabar)
                        .addGap(69, 69, 69)
                        .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtEmpleadoID, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 444, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtContratoID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtEmpleadoID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtFech_Ini, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtFechFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtAreaID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtRolID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSueldo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGrabar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnSalir))
                .addGap(28, 28, 28))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed

    
        if(valida()== true){
            Util util = new Util();
            Contrato contrat = new Contrato();
            String msj;
            
            contrat.setContratoID(Integer.parseInt(txtContratoID.getText()));
            contrat.setEmpleadoID(Integer.parseInt(txtEmpleadoID.getText()));
            contrat.setAreaID(Integer.parseInt(txtAreaID.getText()));
            contrat.setRolID(Integer.parseInt(txtRolID.getText()));
            contrat.setSueldo(Double.parseDouble(txtSueldo.getText()));
            contrat.setFech_Ini(LocalDate.parse(txtFech_Ini.getText()));
            contrat.setFech_Fin(LocalDate.parse(txtFechFin.getText())); 
            if(this.btnGrabar.getText().equals("Grabar")){
                contID = util.idNext("EmpleadoID", "ContratoID");
                contrat.setContratoID(contID);
                this.ContDao.insertaCont(contrat);
                msj = "camibo registrado exitosamente";
            }else{
                contrat.setContratoID(contID);
                this.ContDao.actualizaContrato(contrat);
                msj = "contrato actualizado exitosamente";
            }
                JOptionPane.showMessageDialog(this, msj);
                this.llenaTblContrato("");
                limpia();

    }//GEN-LAST:event_btnGrabarActionPerformed
    }
    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        this.limpia();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        if(this.txtBuscar.getText().isEmpty()){
            this.llenaTblContrato(this.txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarKeyReleased
    }
    private void tblContratoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblContratoMouseClicked
        int idx;
        idx = this.tblContrato.getSelectedRow();
        
        this.txtContratoID.setText(dtm.getValueAt(idx, 0).toString()); 
        this.txtEmpleadoID.setText(dtm.getValueAt(idx, 1).toString());
        this.txtFech_Ini.setText(dtm.getValueAt(idx, 2).toString());
        this.txtFechFin.setText(dtm.getValueAt(idx, 3).toString());
        this.txtAreaID.setText(dtm.getValueAt(idx, 4).toString());
        this.txtRolID.setText(dtm.getValueAt(idx, 5).toString());
        this.txtSueldo.setText(dtm.getValueAt(idx, 6).toString());

        String estadoEnTabla = dtm.getValueAt(idx, 7).toString(); 
        this.cmbEstado.setSelectedItem(estadoEnTabla);

        // 5. Cambiar botón a modo edición
        this.btnGrabar.setText("Actualizar");
        
        this.txtContratoID.setEditable(false);
    }//GEN-LAST:event_tblContratoMouseClicked

    private void txtRolIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRolIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRolIDActionPerformed

    private void txtSueldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSueldoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSueldoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmContrato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmContrato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmContrato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmContrato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmContrato().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<String> cmbEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblContrato;
    private javax.swing.JTextField txtAreaID;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtContratoID;
    private javax.swing.JTextField txtEmpleadoID;
    private javax.swing.JTextField txtFechFin;
    private javax.swing.JTextField txtFechFin1;
    private javax.swing.JTextField txtFech_Ini;
    private javax.swing.JTextField txtRolID;
    private javax.swing.JTextField txtSueldo;
    // End of variables declaration//GEN-END:variables
}
