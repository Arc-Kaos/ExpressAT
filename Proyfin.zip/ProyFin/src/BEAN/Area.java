package BEAN;
public class Area{
    
    private int area_ID;
    private String descArea;
    private String subArea;
    private double centCosto;

    public Area(){

    }

    public Area(int area_ID, String descArea, String nombres, double centCosto){
      this.area_ID = area_ID;
      this.descArea = descArea;
      this.subArea = subArea;
      this.centCosto = centCosto;
    }

    public int getArea_ID() {
        return area_ID;
    }

    public void setArea_ID(int area_ID) {
        this.area_ID = area_ID;
    }

    public String getDescArea() {
        return descArea;
    }

    public void setDescArea(String descArea) {
        this.descArea = descArea;
    }

    public String getsubArea() {
        return subArea;
    }

    public void setsubArea(String subArea) {
        this.subArea = subArea;
    }

    public double getCentCosto() {
        return centCosto;
    }

    public void setCentCosto(double centCosto) {
        this.centCosto = centCosto;
    }
    
}
