package BEAN;
import java.time.LocalDate;
public class Contrato {
    private int contratoID;
    private int empleadoID;
    private LocalDate fech_Ini;
    private LocalDate fech_Fin;
    private int areaID;
    private int rolID;
    private double sueldo;
    private int estado;

    public Contrato() {
    }

    public Contrato(int contratoID, int empleadoID, LocalDate fech_Ini, LocalDate fech_Fin, int areaID, int rolID, double sueldo, int estado) {
        this.contratoID = contratoID;
        this.empleadoID = empleadoID;
        this.fech_Ini = fech_Ini;
        this.fech_Fin = fech_Fin;
        this.areaID = areaID;
        this.rolID = rolID;
        this.sueldo = sueldo;
        this.estado = estado;
    }

    public int getContratoID() {
        return contratoID;
    }

    public void setContratoID(int contratoID) {
        this.contratoID = contratoID;
    }

    public int getEmpleadoID() {
        return empleadoID;
    }

    public void setEmpleadoID(int empleadoID) {
        this.empleadoID = empleadoID;
    }

    public LocalDate getFech_Ini() {
        return fech_Ini;
    }

    public void setFech_Ini(LocalDate fech_Ini) {
        this.fech_Ini = fech_Ini;
    }

    public LocalDate getFech_Fin() {
        return fech_Fin;
    }

    public void setFech_Fin(LocalDate fech_Fin) {
        this.fech_Fin = fech_Fin;
    }

    public int getAreaID() {
        return areaID;
    }

    public void setAreaID(int areaID) {
        this.areaID = areaID;
    }

    public int getRolID() {
        return rolID;
    }

    public void setRolID(int rolID) {
        this.rolID = rolID;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
}

