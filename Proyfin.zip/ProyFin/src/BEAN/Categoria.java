package BEAN;
public class Categoria{
    private int categoriaID;
    private String descCategoria;
    private String obs;

    public Categoria(){
    
    }

    public Categoria(int categoriaID, String descCategoria, String obs) {
        this.categoriaID = categoriaID;
        this.descCategoria = descCategoria;
        this.obs = obs;
    }

    public int getCategoriaID() {
        return categoriaID;
    }

    public void setCategoriaID(int categoriaID) {
        this.categoriaID = categoriaID;
    }

    public String getDescCategoria() {
        return descCategoria;
    }

    public void setDescCategoria(String descCategoria) {
        this.descCategoria = descCategoria;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }
    
}   