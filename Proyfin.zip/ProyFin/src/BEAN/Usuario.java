package BEAN;
public class Usuario{
    private int usuarioID;
    private int empleadoID;
    private String usuario;
    private String password;
    
    public Usuario(){
        
    }

    public Usuario(int usuarioID, int empleadoID, String usuario, String password) {
        this.usuarioID = usuarioID;
        this.empleadoID = empleadoID;
        this.usuario = usuario;
        this.password = password;
    }

    public int getUsuarioID() {
        return usuarioID;
    }

    public void setUsuarioID(int usuarioID) {
        this.usuarioID = usuarioID;
    }

    public int getEmpleadoID() {
        return empleadoID;
    }

    public void setEmpleadoID(int empleadoID) {
        this.empleadoID = empleadoID;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
}    