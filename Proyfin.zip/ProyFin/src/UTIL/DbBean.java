package UTIL;

import java.sql.*;

public class DbBean {

    private static final String DB_URL =
        "jdbc:sqlserver://localhost:1433;databaseName=BDBOTICCA;encrypt=false;trustServerCertificate=true";
    private static final String DB_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "123456789";

    private Connection dbCon;

    public DbBean() {
        conecta();
    }

    private void conecta() {
        try {
            System.out.println("Cargando driver: " + DB_DRIVER);
            Class.forName(DB_DRIVER);
            System.out.println("Driver cargado OK");

            dbCon = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Conexión OK a " + DB_URL);

        } catch (ClassNotFoundException e) {
            System.out.println("❌ Error en clase (no se encontró el driver JDBC)");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("❌ No hay conexión al servidor SQL Server");
            e.printStackTrace();
        }
    }

    public void desconecta() throws SQLException {
        if (dbCon != null && !dbCon.isClosed()) {
            dbCon.close();
        }
    }

    public ResultSet resultadoSQL(String sql) throws SQLException {
        if (dbCon == null) {
            throw new SQLException("No hay conexión (dbCon es null)");
        }
        Statement s = dbCon.createStatement();
        return s.executeQuery(sql);
    }

    public int ejecutaSQL(String sql) throws SQLException {
        if (dbCon == null) {
            throw new SQLException("No hay conexión (dbCon es null)");
        }
        Statement s = dbCon.createStatement();
        return s.executeUpdate(sql);
    }
}
